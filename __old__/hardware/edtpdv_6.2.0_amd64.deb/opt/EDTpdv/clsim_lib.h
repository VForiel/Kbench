/* SPDX-License-Identifier: BSD-3-Clause */

/**
 * @file
 * @copyright Copyright (C) 2011 Engineering Design Team, Inc.
 *
 * Camera Link Simulator Library header file, for use with the EDT CameraLink Simulator (CLS).
 */
#ifndef _CLSIM_H_
#define _CLSIM_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "libpdv.h"

/**
 * @defgroup cls EDT Camera Link Simulator Library
 * The CameraLink Simulator Library provides programming access to the EDT CLS board.
 *
 * The source code for the library is in clsim_lib.c and clsim_lib.h.
 *
 * The following applications are also provided:
 * - pciload:       queries EDT boards and provides utilities to verify and update board firmware
 * - clsiminit:     initializes the CLS
 * - simple_clsend: example code for sending an image or images via the CLS
 * - send_tiffs:    another example application for sending an image or images via the CLS
 * - clink_tester:  unit testing between an EDT frame grabber and an EDT CLS
 */

#define PDV_CLS_DEFAULT_HGAP 300
#define PDV_CLS_DEFAULT_VGAP 400
#define PDV_CLS_DEFAULT_FREQ 20.0

/**
 * @addtogroup cls
 * @{
 */

/**
 * @brief Prints the board state to stdout.
 *
 * @param pdv_p
 *   The open EDT device handle.
 */
EDTAPI void pdv_cls_dump_state(PdvDev pdv_p);

/**
 * @brief Prints board geometry only to stdout.
 *
 * @param pdv_p
 *   The open EDT device handle.
 */
EDTAPI void pdv_cls_dump_geometry(PdvDev pdv_p);

/**
 * @brief Initializes CLS values based on PdvDependent structure in @p pdv_p.
 *
 * @param pdv_p
 *   The open EDT device handle.
 *
 * @return 0 on success
 */
EDTAPI int pdv_cls_set_dep(PdvDev pdv_p);

/**
 * @brief Checks for inconsistencies in the configuration completed by @ref pdv_cls_set_dep().
 *
 * @param pdv_p
 *   The open EDT device handle.
 *
 * @return 0 if ok, otherwise error code.
 */
EDTAPI int pdv_cls_dep_sanity_check(PdvDev pdv_p);

/**
 * @brief Set the width and height of the simulator frame.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param taps
 *   Number of clocks per line.
 * @param depth
 *   Frame depth, in bits of data.
 * @param width
 *   Frame width; columns or pixels of active data.
 * @param height
 *   Frame height; lines of active data.
 * @param hblank
 *   Horizontal blanking, in columns.
 * @param totalwidth
 *   Total width including horizontal blanking if @p hblank is zero.
 * @param vblank
 *   Vertical blanking, in lines.
 * @param totalwidth
 *   Total number of lines including vertical blanking if @p vblank is zero.
 */
EDTAPI void pdv_cls_set_size(PdvDev pdv_p,
                             int taps,
                             int depth,
                             int width,
                             int height,
                             int hblank,
                             int totalwidth,
                             int vblank,
                             int totalheight);

/**
 * @brief Set the values for frame valid (FVAL), line valid (LVAL), and read valid (RVAL) timing.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param taps
 *   Number of clocks per line.
 * @param width
 *   Frame width; columns or pixels of active data.
 * @param Hfvstart
 *   Horizontal FVAL start; column on which the frame signal is valid (high).
 * @param Hfvend
 *   Horizontal FVAL end; column on which the frame signal is no longer valid (low).
 * @param Hlvstart
 *   Horizontal LVAL start; column on which the line signal is valid (high).
 * @param Hlvend
 *   Horizontal LVAL end; column on which the line signal is no longer valid (low).
 * @param Hrvstart
 *   Horizontal RVAL start; column on which the read signal is valid (high).
 * @param Hrvend
 *   Horizontal RVAL end; column on which the read signal is no longer valid (low).
 */
EDTAPI void pdv_cls_set_line_timing(PdvDev pdv_p,
                                    int width,
                                    int taps,
                                    int Hfvstart,
                                    int Hfvend,
                                    int Hlvstart,
                                    int Hlvend,
                                    int Hrvstart,
                                    int Hrvend);

/**
 * @brief When set, once the start-of-frame conditions are met, the simulator runs forever,
 * emulating a linescan camera (as if the total vertical active and total vertical count maximum
 * were set to infinity.)
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param state
 *   Enable (1) or disable (0) linescan.
 */
EDTAPI void pdv_cls_set_linescan(PdvDev pdv_p, int state);

/**
 * @brief Enable/Disable line valid timing during vertical blanking.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param state
 *   Enable (1) or disable (0) continuous line valid.
 */
EDTAPI void pdv_cls_set_lvcont(PdvDev pdv_p, int state);

/**
 * @brief Enable/Disable ReadValid Enable (RVEN); if enabled allows image width padding (with
 * dummy data from the Fill register values), to output an image that is wider than the actual image
 * data provided.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param state
 *   Enable (1) or disable (0) ReadValid.
 */
EDTAPI void pdv_cls_set_rven(PdvDev pdv_p, int state);

/**
 * @brief Enable/Disable UART looping (echo) of serial data; if enabled allows testing of the
 * serial port on an EDT Framegrabber.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param state
 *   Enable (1) or disable (0) uart looping.
 */
EDTAPI void pdv_cls_set_uartloop(PdvDev pdv_p, int state);

/**
 * @brief Enable/Disable CLS FIFO for small (less than 16 KB) images.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param state
 *   Enable (1) or disable (0) the simulator FIFO.
 */
EDTAPI void pdv_cls_set_smallok(PdvDev pdv_p, int state);

/**
 * @brief Enables or disables four-tap interleaving (the four-tap re-ordering of 8-bit pixel
 * values).
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param state
 *   Enable (1) or disable (0) interleave.
 */
EDTAPI void pdv_cls_set_intlven(PdvDev pdv_p, int state);

/**
 * @brief Enable/Disable frame count in the first word of each frame.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param state
 *   Enable (1) or disable (0) the first word frame count.
 */
EDTAPI void pdv_cls_set_firstfc(PdvDev pdv_p, int state);

/**
 * @brief Enable/Disable internal image data generation; allows image data to come from the
 * counters instead of the DMA stream.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param state
 *   Enable (1) to output internally-generated data, disable (0) to output data from the host via
 * DMA.
 */
EDTAPI void pdv_cls_set_datacnt(PdvDev pdv_p, int state);

/**
 * @brief Controls state of the board's green LED.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param state
 *   Enable (1) to turn on LED, disable (0) to turn off LED.
 */
EDTAPI void pdv_cls_set_led(PdvDev pdv_p, int state);

/**
 * @brief Selects which input pins to look at for external trigger; CC1 or CC2.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param select
 *   Set input trigger to CC2 (1) or CC1 (0).
 */
EDTAPI void pdv_cls_set_trigsrc(PdvDev pdv_p, int select);

/**
 * @brief Set the trigger polarity.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param polarity
 *   Set trigger polarity to positive (1) or negative (0).
 */
EDTAPI void pdv_cls_set_trigpol(PdvDev pdv_p, int polarity);

/**
 * @brief Enable/Disable frame-valid triggering; if enabled CLS waits at the start of each frame
 * until a trigger is detected.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param state
 *   Enable (1) or disable (0) frame-valid triggering.
 */
EDTAPI void pdv_cls_set_trigframe(PdvDev pdv_p, int state);

/**
 * @brief Enable/Disable line-valid triggering; if enabled CLS waits at the start of each raster
 * until a trigger is detected.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param state
 *   Enable (1) or disable (0) line-valid triggering.
 */
EDTAPI void pdv_cls_set_trigline(PdvDev pdv_p, int state);

/**
 * @brief Clear the CFG register including the FIFO_RESET bit (bit 3, 0x08) which clears the FIFO
 * and starts the CLS.
 *
 * @param pdv_p
 *   The open EDT device handle.
 */
EDTAPI void pdv_cls_sim_start(PdvDev pdv_p);

/**
 * @brief Set the CFG register FIFO_RESET bit (bit 3, 0x08) which stops the CLS.
 *
 * @param pdv_p
 *   The open EDT device handle.
 */
EDTAPI void pdv_cls_sim_stop(PdvDev pdv_p);

/**
 * @brief Re-intializes and enables the serial communication.
 *
 * @param pdv_p
 *   The open EDT device handle.
 */
EDTAPI void pdv_cls_init_serial(PdvDev pdv_p);

/**
 * @brief Set the height of outgoing frames, as well as the number of blank lines (@p vblank)
 * between valid lines.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param height
 *   Frame height; lines of active data.
 * @param vblank
 *   Vertical blanking, in lines.
 */
EDTAPI void pdv_cls_set_height(PdvDev pdv_p, int height, int vblank);

/**
 * @brief Set the width of outgoing frames, as well as the number of blank columns (@p hblank)
 * between valid columns.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param width
 *   Frame width; columns or pixels of active data.
 * @param hblank
 *   Horizontal blanking, in columns.
 */
EDTAPI void pdv_cls_set_width(PdvDev pdv_p, int width, int hblank);

/**
 * @brief Set the width of outgoing frames, as well as the number of blank columns (@p hblank)
 * between valid columns, start and end of both line valid and read valid.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param width
 *   Frame width; columns or pixels of active data.
 * @param hblank
 *   Horizontal blanking, in columns.
 * @param hlvstart
 *   Horizontal LVAL start; column on which the line signal is valid (high).
 * @param hlvend
 *   Horizontal LVAL end; column on which the line signal is no longer valid (low).
 * @param hrvstart
 *   Horizontal RVAL start; column on which the read signal is valid (high).
 * @param hrvend
 *   Horizontal RVAL end; column on which the read signal is no longer valid (low).
 */
EDTAPI void pdv_cls_set_width_lval_rval(PdvDev pdv_p,
                                        int width,
                                        int hblank,
                                        int hlvstart,
                                        int hlvend,
                                        int hrvstart,
                                        int hrvend);

/**
 * @brief Set the depth of outgoing frames.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param value
 *   Frame depth, in bits of data.
 */
EDTAPI void pdv_cls_set_depth(PdvDev pdv_p, int value);

/**
 * @brief Set the pxiel clock frequency (in MHz).
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param freq
 *   The new pixel clock frequency (MHz); valid range is 19.9-85.1, a warning is produced for
 * frequencies outside this range.
 */
EDTAPI void pdv_cls_set_clock(PdvDev pdv_p, double freq);

/**
 * @brief Set the left and right fill values when RVEN (@ref pdv_cls_set_rven()) is enabled.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param left
 *   The 8 bit left fill value (FillA in CLS docs).
 * @param right
 *   The 8 bit right fill value (FillB in CLS docs).
 */
EDTAPI void pdv_cls_set_fill(PdvDev pdv_p, uint8_t left, uint8_t right);

/**
 * @brief Set the horizontal start and end positions if RVEN (@ref pdv_cls_set_rven()) is enabled.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param HrvStart
 *   Horizontal RVAL start; column on which the line signal is valid (high).
 * @param HrvEnd
 *   Horizontal RVAL end; column on which the line signal is no longer valid (low).
 */
EDTAPI void pdv_cls_set_readvalid(PdvDev pdv_p, uint16_t HrvStart, uint16_t HrvEnd);

/**
 * @brief Set the values for Data Valid (DVAL) timing.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param skip
 *   Number of pixel clocks to skip per DVAL strobe.
 * @param mode
 *   Simulated DVAL signal during blanking.
 *   Valid values: 0 low, 1 high, 2 to mirror behavior during active video, 3 always low.
 */
EDTAPI void pdv_cls_set_dvalid(PdvDev pdv_p, uint8_t skip, uint8_t mode);

/**
 * @brief Set the start address and delta for each tap.
 * - Start address is the 12-bit address of an 8-bit pixel within the 4096 pixel raster.
 * - Delta is the amount added to the pixel address with each pixel clock.
 *
 * @param pdv_p
 *   The open EDT device handle.
 * @param tap0start
 *   The start address for tap 0.
 * @param tap0delta
 *   The delta for tap 0.
 * @param tap1start
 *   The start address for tap 1.
 * @param tap1delta
 *   The delta for tap 1.
 * @param tap2start
 *   The start address for tap 2.
 * @param tap2delta
 *   The delta for tap 2.
 * @param tap3start
 *   The start address for tap 3.
 * @param tap3delta
 *   The delta for tap 3.
 */
EDTAPI void pdv_cls_setup_interleave(PdvDev pdv_p,
                                     short tap0start,
                                     short tap0delta,
                                     short tap1start,
                                     short tap1delta,
                                     short tap2start,
                                     short tap2delta,
                                     short tap3start,
                                     short tap3delta);

/**
 * @brief Computes the vertical gap (vgap/vblank) value.
 *
 * @param pdv_p
 *   The open EDT device handle.
 *
 * @return The vertical gap value, in lines.
 */
EDTAPI int pdv_cls_get_vgap(PdvDev pdv_p);

/**
 * @brief Computes the horizontal gap (hgap/hblank) value.
 *
 * @param pdv_p
 *   The open EDT device handle.
 *
 * @return The horizontal gap value, in columns.
 */
EDTAPI int pdv_cls_get_hgap(PdvDev pdv_p);

/* These are used by clsiminit if no value for blanking is specified. */
#define PDV_CLS_DEFAULT_HGAP 300
#define PDV_CLS_DEFAULT_VGAP 400

/**
 * @brief Computes the frame time in milliseconds.
 *
 * @param pdv_p
 *   The open EDT device handle.
 *
 * @return the computed frame time
 */
EDTAPI double pdv_cls_frame_time(PdvDev pdv_p);

/** @} */ /* end cls group */

#ifdef __cplusplus
}
#endif

#endif /* _CLSIM_H_ */
