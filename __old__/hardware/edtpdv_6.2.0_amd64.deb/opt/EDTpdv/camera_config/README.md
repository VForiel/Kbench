# Camera Configuration Files

SPDX-License-Identifier: BSD-3-Clause

Copyright (C) 2022 Engineering Design Team, Inc.

The camera configuration files provided in this directory are used by EDT
utilities, such as `initcam` or `clsiminit`. Users may choose to copy and modify
a camera configuration file to better suite the target camera hardware or
application.

Additional camera configuration files for a wide variety of vendors and cameras
are included in the `edt_camera_config_extra` archive in this directory.
