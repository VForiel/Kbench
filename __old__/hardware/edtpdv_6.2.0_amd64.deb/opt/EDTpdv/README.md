# EDT PDV Quick Start Guide

Engineering Design Team (EDT), Inc.
https://edt.com

SPDX-License-Identifier: BSD-3-Clause
Copyright (C) 2016 Engineering Design Team, Inc.

Revised: Oct. 2023

[TOC]

## Location of files

By default the PDV package is installed to:

- On Windows: `C:\EDT\pdv`
- On Linux: `/opt/EDTpdv`

This directory will be referred to as the "installation directory."

## Introduction

This README file contains quick start information, changes and additions
for your EDT PCI Digital Vision (PDV) product, such as our VisionLink F1, F4,
and CLS. For complete documentation and software updates, go to https://edt.com
and navigate to the specific product page.

Also see the other README.xxx files in the installation directory for
information on specific tasks, and CHANGELOG.md for changes between versions.

## Quick Start Guide

The most useful examples/diagnostics are `take`, `simple_take`, and `pciload`.
You can run any of these programs with the -h flag for description and usage.

Example source code is provided in the `/examples/` directory. See the README
file in that directory for instructions on how to get started with the examples.

To test only the frame grabber interface, you can run the board in simulator
mode without a camera. The method differs depending on the board in use. With
EDT VisionLink boards, use the "phantom" channel 2 which produces a 16-bit
gray ramp internally. Access channel 2 by using the `-c 2` flag in applications,
for example:

    ./initcam -c 2 -f camera_config/<file>

...where `<file>` is one of the .cfg files in the camera config directory.
Then run "take" to capture an image and optionally save the image to a file.

    ./take -u 0 -c 2

### Windows

Open Device Manager and expand the "PCI Devices" entry to see which EDT PDV
devices you may have installed in a given system.

Most PDV utilities are command line applications. Open PowerShell or Command Prompt
and navigate to the installation directory to launch these applications.
For example, to launch `pciload` to list all installed PDV boards in the system:

    ./bin/pciload.exe -p

The PDV package provides a Camera Link serial interface library for the
VisionLink frame grabbers, `clseredt.dll`, and installs it to the location
defined by the Camera Link specification. Typically, for a 64-bit system, this
will be `C:\Program Files\CameraLink\Serial\`. See your camera's documentation
for information on any camera-specific control GUI that supports this interface.

### Linux

Most PDV utilities are command line applications. Open your favorite terminal
and navigate to the installation directory to find the binary applications.
For example, to launch `pciload` to list all installed PDV boards in the system:

    ./pciload -p

If the "pciutils" package is installed, run `lspci -d 123d:` to list any EDT PCI
devices installed in your system.

If the "kmod" package is installed, run `lsmod | grep edt_pci` to check if the
`edt_pci_pdv` kernel module is currently loaded.

#### Linux Kernel Module

The PDV kernel module (`edt_pci_pdv`) is compiled during installation of
the PDV package with the help of Dynamic Kernel Module Support (DKMS). The DKMS
tooling should automatically sign the module upon install.

However, it is possible your kernel may fail to load the module due to UEFI
Secure Boot being enabled, kernel signature enforcement being enabled, the DKMS
signing certificate is not yet trusted by your system, or some combination
thereof. EDT PCI devices will be inaccessible until the kernel module can be
properly loaded.

There are two options to correct this issue:

1. For _temporary_ testing purposes, ensure both UEFI Secure Boot and your
   kernel's signature enforcement are disabled.
   - Not ideal, for system security reasons.
   - Disable UEFI Secure Boot via the BIOS Settings.
   - Disable signature enforcement via kernel parameter "CONFIG_MODULE_SIG_FORCE".
   - Re-run (as sudo/root) the setup.sh script within the installation directory.
2. EDT is happy to help diagnose a kernel module loading problem.
   - Collect the `install.log` from the installation directory.
   - Collect the DKMS log, either `install_dkms_make.log` from the installation
     directory or from `/var/lib/dkms/edt_pci_pdv/<package_version>/make.log`
   - Submit a service request and attach both log files at:
     https://edt.com/technical-support-request/

## Updating Firmware

### Frame Grabber Products

EDT frame grabber firmware may be updated occasionally. These firmware files are
provided as separate add-on packages.

To compare the current FPGA firmware running on the board with any firmware files
you may have additionally installed to the installation directory, navigate
to the PDV directory in a command window (terminal), and run:

    ./pciload verify

The program will output the dates, revision numbers and file id of the FPGA
firmware. If they match, then there is no need for a field upgrade. If
they differ, upgrade the firmware by running:

    ./pciload update

Note that the FPGA only reloads firmware during power-up, so after loading new
firmware with pciload, it won't be active until the system has power cycled.
This requires shutting down, waiting a few seconds, then powering back on.
Rebooting is not sufficient; PCI devices are often not powered off during a reboot.

pciload has several options that can be used in other than the default case
(e.g. -u 1 to update the second of 2 boards in the system). For a list of all
options, run:

    ./pciload -h

IMPORTANT: The features and functionality of an FPGA-based EDT product are
dependent on the firmware variant and version. For example, Camera Link medium
or full mode acquisition may not be supported in standard firmware, but
alternate firmware EDT provides may implement this. For details, refer to the
user guide for your product.

### Remote Products (RCX Module)

EDT VisionLink Remote Camera eXtender (RCX) firmware updates are occasionally
provided as well. The process is similar to process described above, except that
rcxload is used. To upgrade a VisionLink RCX module, put the module into blink
code 3-3 (see RCX Users Guide for instructions), make sure the cable is
connected to channel 0 of a VisionLink F1 or F4 frame grabber (it doesn't have
to be connected to a camera), then run:

    ./rcxload -u 0 flash/rcx/rgb11.rcx

After the update and assuming no errors, switch the module into the
appropriate blink code for its intended use. Note that with this version,
the blink codes may have changed; see the blink code table in the current
version of the RCX Users Guide, available on the EDT website, https://edt.com .

## Partial List of Included Files

(Note: Linux versions don't have the `.exe` extension on executables.)

```
README
    This file.

VERSION
    Version number of this package.

libpdv.h
libpdv.so   (unix/linux)
libpdv.lib  (windows)
    PCI DV interface library and associated C header file.

camera_config/*.cfg
    Camera configuration files.

flash/
    Directory of FPGA firmware files ("bitfiles").

cl_speed.exe
    Measures bus bandwidth on a cameralink board

dvinfo.exe
    Runs diagnostic tests, useful for tech support (email to edt)

initcam.exe
    Initializes the board for a specific camera.

pciload.exe
    Utility program for field upgrades of PCI I/F PROMs.

pdb.exe
    Register-level debug / utility program.

rcxload.exe
    Firmware updater for VisionLink RCX modules.

setdebug.exe
    Diagnostic program that sets the device driver debug level.

speedtest.exe
    Utility program that tests speed of the interface/PCI bus.

take.exe
    Diagnostic program for testing acquire/save with many options
    and variations (complex version of simple_take).

doc/README.visionlink_dual
    Using EDT camera link FGs with two base mode cameras.

doc/README.clsiminit
    Initializing an EDT Camera Link simulator board.

doc/README.lnx_pkg_reqs
    Linux package requirements for using EDT boards / apps.

doc/README.send_tiffs
    Using send_tiffs to send TIFF files with the VisionLink CLS.

examples/simple_take.c
    Example program showing simple acquire/save using pdvlib calls
    with ring buffer pipelining (good starting point for programmers!).
```
