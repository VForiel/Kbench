# v6.0.0 Changelog Addendum

SPDX-License-Identifier: BSD-3-Clause

Copyright (C) 2022 Engineering Design Team, Inc.

The 6.0.0 release of EDT packages is significantly different from previous 5.x releases.
This document extends the CHANGELOG to enumerate applications and devices which are no longer supported.


## Removed internal or deprecated headers

The following list of header files are no longer included in EDT's PCD or PDV packages.
Either they were internal components not intended to be public facing, or they
target hardware which is now discontinued.

```
initpcd.h
lib_si5375.h
pciload.h
pciload_constants.h
edt_oc192.h
edtregbits.h
pdv_interlace_methods.h
edt_vco.h
```

## Removed API functions

The following list of functions are no longer included as part of public-facing
APIs provided by libraries in this package.


**edt_bitload.h**

| Function                                     | Reason                         |
| -------------------------------------------- | ------------------------------ |
| bf_sort_entries                              | Unused/Deprecated              |
| bf_allocate                                  | Unused/Deprecated              |
| edt_bitload_basedir                          | Internal                       |
| edt_program_flash_direct                     | Internal                       |
| edt_program_mezzanine_direct                 | Internal                       |
| edt_bitfile_read_header                      | Internal                       |
| edt_access_bitfile                           | Internal                       |
| edt_bitload_from_prom                        | Unused/Deprecated              |
| bitload_has_slashes                          | Internal                       |
| edt_bitload_devid_to_bitdir                  | Internal                       |
| edt_get_x_header                             | Unused/Deprecated              |
| edt_bitfile_load_array                       | Unused/Deprecated              |
| edt_bitfile_open_file                        | Internal                       |

**edt_error.h**

| Function                                     | Reason                         |
| -------------------------------------------- | ------------------------------ |
| edt_msg_init_names                           | Unused/Deprecated              |
| edt_msg_init_files                           | Renamed: edt_msg_init_file()   |
| edt_msg_add_level                            | Unused/Deprecated              |
| edt_msg_printf_perror                        | Unused/Deprecated              |
| lvl_printf                                   | Deprecated                     |

**edt_vco.h / edt_ss_vco.h**

| Function                                     | Reason                         |
| -------------------------------------------- | ------------------------------ |
| edt_set_pll_clock                            | Unused/Deprecated              |

**edt_threep.h**

| Function                                     | Reason                         |
| -------------------------------------------- | ------------------------------ |
| dump_threep_freq_cntrs                       | Unused/Deprecated              |
| edt_threep_si5326_dump                       | Internal                       |
| edt_threep_si5326_load_array                 | Internal                       |
| edt_threep_amcc_reg_set_bits                 | Internal                       |
| edt_3p_mn_ser_dev_reg_write                  | Internal                       |
| edt_3p_mn_ser_dev_reg_read                   | Internal                       |
| edt_3p_adt7461_reg_read                      | Internal                       |
| edt_3p_adt7461_reg_write                     | Internal                       |
| edt_3p_v6_temp                               | Renamed to "edt_threep_v6_temp()" |

**libdvu.h**

| Function                                     | Reason                         |
| -------------------------------------------- | ------------------------------ |
| dvu_init_window                              | Unused/Deprecated              |
| dvu_read_window                              | Unused/Deprecated              |
| dvu_reset_window                             | Unused/Deprecated              |
| dvu_free_window                              | Unused/Deprecated              |
| dvu_load_lookup                              | Unused/Deprecated              |
| dvu_save_lookup                              | Unused/Deprecated              |
| dvu_lookup                                   | Unused/Deprecated              |
| dvu_histeq                                   | Unused/Deprecated              |
| dvu_exp_histeq                               | Unused/Deprecated              |
| dvu_winscale                                 | Unused/Deprecated              |
| ten2one                                      | Unused/Deprecated              |
| dvu_free_tables                              | Unused/Deprecated              |
| -- others --                                 | Renamed to have a "edt_dvu_" prefix |


**edt_os_utils.h** (renamed from edt_utils.h)

| Function                                     | Reason                         |
| -------------------------------------------- | ------------------------------ |
| edt_alloc_aligned                            | Deprecated                     |
| edt_free_aligned                             | Deprecated                     |
| edt_wait_for_console_input                   | Unused/Deprecated              |
| edt_get_datestr                              | Unused/Deprecated              |
| edt_elapsed                                  | Deprecated                     |
| edt_file_exists                              | Deprecated                     |
| edt_mkdir                                    | Deprecated                     |
| edt_mkdir_p                                  | Deprecated                     |
| edt_disk_size                                | Deprecated, unimplemented on Linux |
| edt_disk_used                                | Deprecated, unimplemented on Linux |

**libedt_timing.h**

| Function                                     | Reason                         |
| -------------------------------------------- | ------------------------------ |
| edt_spi_get_byte_nointr                      | Deprecated. Use edt_spi_get_byte() |

**libedt.h**

| Function                                     | Reason                         |
| -------------------------------------------- | ------------------------------ |
| edt_lcr_read                                 | Unused                         |
| edt_lcr_write                                | Unused                         |
| edt_init_direct_dma                          | Unused                         |
| edt_direct_read                              | Unused                         |
| edt_direct_write                             | Unused                         |
| edt_get_reftime                              | Unused                         |
| edt_next_writebuf_index                      | Deprecated/Unimplemented       |
| edt_get_current_dma_buf                      | Unused                         |
| edt_get_bytecount                            | Obsolete, use edt_get_bufbytecount() |
| edt_get_timecount                            | Deprecated/Unimplemented       |
| edt_read_start_action                        | Unused/Deprecated              |
| edt_read_end_action                          | Unused/Deprecated              |
| edt_write_start_action                       | Unused/Deprecated              |
| edt_write_end_action                         | Unused/Deprecated              |
| edt_user_dma_wakeup                          | Unused/Deprecated              |
| edt_had_user_dma_wakeup                      | Unused/Deprecated              |
| edt_intfc_write                              | Renamed to edt_intfc_write8()  |
| edt_intfc_read                               | Renamed to edt_intfc_read8()   |
| edt_intfc_write_short                        | Renamed to edt_intfc_write16() |
| edt_intfc_read_short                         | Renamed to edt_intfc_read16()  |
| edt_intfc_write_32                           | Renamed to edt_intfc_write32() |
| edt_intfc_read_32                            | Renamed to edt_intfc_read32()  |
| edt_get_firstflush                           | Obsolete                       |
| edt_set_eodma_int                            | Deprecated/Unimplemented       |
| edt_get_msg_unit                             | Deprecated, use edt_get_msg()  |
| edt_send_dma                                 | Deprecated/Unimplemented       |
| edt_wait_avail                               | Deprecated/Unimplemented       |
| edt_init_mac8100                             | Deprecated/Unimplemented       |
| edt_read_mac8100                             | Deprecated/Unimplemented       |
| edt_write_mac8100                            | Deprecated/Unimplemented       |
| edt_flush_resp                               | Deprecated/Unimplemented       |
| edt_set_flush                                | Deprecated/Unimplemented       |
| edt_flush_mode                               | Deprecated/Unimplemented       |
| edt_set_rci_dma                              | Deprecated                     |
| edt_get_rci_dma                              | Deprecated                     |
| edt_set_rci_chan                             | Deprecated                     |
| edt_get_rci_chan                             | Deprecated                     |
| edt_set_ignore_signals                       | Unused/Deprecated              |
| edt_flipbits                                 | Internal                       |
| edt_idstring                                 | Replace with edt_idstr()       |
| edt_detect_boards_filter                     | Unused                         |
| edt_perror                                   | Replace with edt_msg_perror()  |
| edt_envvar_from_devstr                       | Unused/Deprecated              |
| edt_set_mezz_chan_bitpath                    | Unused/Deprecated              |
| edt_get_last_bitpath                         | Unused/Deprecated              |
| edt_set_last_bitpath                         | Unused/Deprecated              |
| edt_get_full_board_id                        | Internal                       |
| edt_set_sync_interval                        | Unused/Deprecated              |
| edt_lockoff                                  | Deprecated                     |
| edt_dmasync_fordev                           | Deprecated                     |
| edt_dmasync_forcpu                           | Deprecated                     |
| edt_set_timetype                             | Deprecated                     |
| edt_set_abortintr                            | Unused/Deprecated              |
| edt_write_pio                                | Unused/Deprecated              |
| edt_set_persistent_buffers                   | Deprecated                     |
| edt_get_persistent_buffers                   | Deprecated                     |
| edt_check_1_vs_4                             | Internal                       |
| edt_flash_get_do_fast                        | Unused                         |
| pcd_get_funct                                | Replace with edt_intfc_read8(edt_p, PCD_FUNCT) |
| pcd_set_funct                                | Replace with edt_intfc_write8(edt_p, PCD_FUNCT, value) |
| pcd_set_statsig                              | Deprecated/Unimplemented       |
| pcd_get_stat                                 | Replace with edt_intfc_read8(edt_p, PCD_STAT) |
| pcd_get_stat_polarity                        | Replace with 0xF & edt_intfc_read8(edt_p, PCD_STAT_POLARITY) |
| pcd_set_stat_polarity                        | Replace with edt_intfc_read8(), then edt_intfc_write8() of the PCD_STAT_POLARITY register to modify only lower 4 bits. |
| pcd_set_byteswap                             | Replace with edt_intfc_read8(), then edt_intfc_write8() if the PCD_CONFIG register to modify only bit 0.
| pcd_get_cmd                                  | Replace with edt_intfc_read8(edt_p, PCD_CMD) |
| pcd_set_cmd                                  | Replace with edt_intfc_write8(edt_p, PCD_CMD, value) |
| pcd_flush_channel                            | Replace with edt_disable_channel(), edt_flush_channel(), edt_enable_channel() [in that order] |
| pcd_get_option                               | Replace with edt_intfc_read8(edt_p, PCD_OPTION) |
| edt_set_funct_bit                            | Replace with edt_reg_or(edt_p, PCD_FUNCT, mask) |
| edt_clr_funct_bit                            | Replace with edt_reg_and(edt_p, PCD_FUNCT, ~mask) |
| edt_set_pllct_bit                            | Replace with edt_reg_or(edt_p, PDV_PLL_CTL, mask) |
| edt_clr_pllct_bit                            | Replace with edt_reg_and(edt_p, PDV_PLL_CTL, ~mask) |
| edt_ioctl_nt                                 | Internal                       |
| pcd_pio_init                                 | Unused/Deprecated              |
| pcd_pio_flush_fifo                           | Unused/Deprecated              |
| pcd_pio_write                                | Unused/Deprecated              |
| pcd_pio_read                                 | Unused/Deprecated              |
| pcd_pio_set_direction                        | Unused/Deprecated              |
| pcd_pio_intfc_write                          | Unused/Deprecated              |
| pcd_pio_intfc_read                           | Unused/Deprecated              |
| edt_set_continuous                           | Internal                       |
| edt_set_dependent                            | Only used in PDV package. Renamed to pdv_set_dependent() in libpdv.h |
| edt_get_dependent                            | Only used in PDV package. Renamed to pdv_get_dependent() in libpdv.h |
| edt_cancel_current_dma                       | Internal                       |
| sse_set_out_clk                              | Unused/Deprecated              |
| sse_shift                                    | Unused/Deprecated              |
| edt_set_sgbuf                                | Replace with edt_set_buffer_size() |
| edt_set_merge                                | Unused/Deprecated              |
| edt_send_msg                                 | Replace with pdv_serial_binary_command() |
| edt_get_msg                                  | Replace with pdv_serial_read() |
| edt_serial_wait                              | Replace with pdv_serial_wait() |
| edt_reset_serial                             | Replace with pdv_serial_reset() |
| edt_set_direction                            | Internal                       |

**libpdv.h**

| Function                                     | Reason                         |
| -------------------------------------------- | ------------------------------ |
| pdv_perror                                   | Replace with edt_msg_perror()  |
| pdv_setdebug                                 | Replace with pdv_set_debug()   |
| pdv_set_aperture                             | Obsolete                       |
| pdv_get_aperture                             | Obsolete                       |
| pdv_set_interlace                            | Obsolete                       |
| pdv_get_interlaced                           | Obsolete                       |
| pdv_set_mode                                 | Obsolete                       |
| pdv_variable_size                            | Obsolete                       |
| pdv_set_gain_ch                              | Obsolete                       |
| pdv_setup_continuous_channel                 | Obsolete                       |
| pdv_start_image                              | Replace with pdv_start_images(pdv_p, 1) |
| pdv_wait_image                               | Replace with pdv_wait_images(pdv_p, 1) |
| pdv_wait_image_raw                           | Replace with pdv_wait_image_timed_raw(pdv_p, timep=NULL, skip_deinterlace=true) |
| pdv_wait_image_timed                         | Replace with pdv_wait_image_timed_raw(pdv_p, timep, skip_deinterlace=false) |
| pdv_wait_images_raw                          | Replace with pdv_wait_images_timed_raw(pdv_p, count, timep=NULL, skip_deinterlace=true) |
| pdv_wait_images_timed                        | Replace with pdv_wait_images_timed_raw(pdv_p, count, timep, skip_deinterlace=false) |
| pdv_wait_last_image_raw                      | Replace with pdv_wait_last_image_timed_raw(pdv_p, timep=NULL, skip_deinterlace=true) |
| pdv_wait_last_image_timed                    | Replace with pdv_wait_last_image_timed_raw(pdv_p, timep, skip_deinterlace=false) |
| pdv_last_image_timed                         | Replace with pdv_wait_last_image_timed_raw(pdv_p, timep, skip_deinterlace=false) |
| pdv_last_image_timed_raw                     | Replace with pdv_wait_last_image_timed_raw(pdv_p, timep, skip_deinterlace=true) |
| pdv_wait_next_image_raw                      | Replace with pdv_wait_next_image_timed_raw(pdv_p, num_skipped, NULL, skip_deinterlace) |
| pdv_update_values_from_camera                | Deprecated                     |
| pdv_camera_type                              | Replace with pdv_get_camera_type() |
| pdv_set_frame_height                         | Deprecated                     |
| pdv_set_depth                                | Replace with pdv_set_depth_extdepth_dpath() |
| pdv_set_extdepth                             | Replace with pdv_set_depth_extdepth_dpath() |
| pdv_set_depth_extdepth                       | Replace with pdv_set_depth_extdepth_dpath() |
| pdv_get_rawio_size                           | Unused/Deprecated              |
| pdv_get_allocated_size                       | Unused/Deprecated              |
| pdv_shutter_method                           | Replace with pdv_get_shutter_method() |
| pdv_set_exposure_mcl                         | Internal. Use pdv_set_exposure() |
| pdv_auto_set_timeout                         | Internal. Use pdv_set_timeout(pdv_p, -1) |
| pdv_timeout_cleanup                          | Deprecated. Use pdv_timeout_restart() with new boards |
| pdv_do_xregwrites                            | Internal                       |
| pdv_serial_check_enabled                     | Internal                       |
| pdv_serial_command_flagged                   | Internal                       |
| pdv_serial_binary_command_flagged            | Internal                       |
| pdv_send_basler_frame                        | Renamed to pdv_serial_write_basler() |
| pdv_read_basler_frame                        | Renamed to pdv_serial_read_basler() |
| pdv_send_duncan_frame                        | Renamed to pdv_serial_write_duncan() |
| pdv_read_duncan_frame                        | Renamed to pdv_serial_read_duncan() |
| pdv_set_serial_delimiters                    | Renamed to pdv_serial_set_delimiters() |
| pdv_reset_serial                             | Renamed to pdv_serial_reset()  |
| pdv_serial_txrx                              | Unused/Deprecated              |
| pdv_serial_command_hex                       | Internal                       |
| pdv_read_response                            | Deprecated                     |
| pdv_get_serial_block_size                    | Renamed pdv_serial_get_block_size() |
| pdv_set_serial_block_size                    | Renamed pdv_serial_set_block_size() |
| ES10deInterleave                             | Unused/Deprecated              |
| ES10_byte64                                  | Unused/Deprecated              |
| ES10_word_deInterleave                       | Unused/Deprecated              |
| ES10_word_deInterleave_odd                   | Unused/Deprecated              |
| ES10_word_deInterleave_hilo                  | Unused/Deprecated              |
| dalsa_4ch_deInterleave                       | Unused/Deprecated              |
| dalsa_2ch_deInterleave                       | Unused/Deprecated              |
| specinst_4port_deInterleave                  | Unused/Deprecated              |
| merge_image                                  | Unused/Deprecated              |
| pdv_mark_ras                                 | Internal                       |
| pdv_mark_bin                                 | Internal                       |
| pdv_mark_bin_16                              | Unused/Deprecated              |
| pdv_set_baud                                 | Renamed to pdv_serial_set_baud() |
| pdv_get_baud                                 | Renamed to pdv_serial_get_baud() |
| pdv_check_fpga_rev                           | Internal                       |
| pdv_check                                    | Unused/Deprecated              |
| pdv_checkfrm                                 | Renamed to pdv_check_frame()   |
| pdv_start_hardware_continuous                | Internal. Prefer pdv_start_images(pdv_p, count=0), but can use pdv_setup_continuous() |
| pdv_stop_hardware_continuous                 | Internal. Use pdv_stop_continuous() |
| pdv_invert                                   | Renamed to pdv_set_invert()    |
| pdv_send_break                               | Renamed to pdv_serial_send_break() |
| pdv_setsize                                  | Renamed to pdv_set_image_size() |
| pdv_image_size                               | Renamed to pdv_get_imghdr_size() |
| pdv_get_imagesize                            | Renamed to pdv_get_image_size() |
| pdv_get_dmasize                              | Renamed to pdv_get_dma_size()  |
| pdv_set_buffers                              | Deprecated                     |
| pdv_set_buffers_x                            | Deprecated                     |
| pdv_force_single                             | Renamed to pdv_get_force_single() |
| pdv_pause_for_serial                         | Renamed to pdv_get_pause_for_serial() |
| pdv_dalsa_ls_set_expose                      | Internal                       |
| pdv_is_kodak_i                               | Internal                       |
| pdv_is_atmel                                 | Unused/Deprecated              |
| pdv_cl_get_fv_counter                        | Renamed to pdv_cl_get_fval_counter() |
| pdv_cl_reset_fv_counter                      | Renamed to pdv_cl_reset_fval_counter() |
| pdv_start_expose                             | Unused/Deprecated              |
| pdv_set_exposure_basler202k                  | Internal                       |
| pdv_set_gain_basler202k                      | Internal                       |
| pdv_set_offset_basler202k                    | Internal                       |
| pdv_set_exposure_duncan_ch                   | Internal                       |
| pdv_set_gain_duncan_ch                       | Internal                       |
| PDV_TIMESTAMP_SIZE                           | Unused                         |
| get_bayer_luts                               | Unused                         |
| set_bayer_parameters                         | Internal. Use pdv_set_full_bayer_parameters() |
| set_bayer_even_odd_row_scale                 | Unused                         |
| pdv_is_dvc                                   | Internal                       |
| pdv_set_binning_dvc                          | Relates to discontinued PCI DV44 product |
| pdv_set_mode_dvc                             | Relates to discontinued DV C-Link or DV44 products |
| pdv_get_dvc_state                            | Unused/Deprecated              |
| pdv_set_waitchar                             | Renamed to pdv_serial_set_waitchar() |
| pdv_get_waitchar                             | Renamed to pdv_serial_get_waitchar() |
| pdv_strobe                                   | Deprecated                     |
| pdv_set_strobe_dac                           | Deprecated                     |
| pdv_enable_strobe                            | Deprecated                     |
| pdv_strobe_method                            | Deprecated                     |

**lib_two_wire.h**

| Function                                     | Reason                         |
| -------------------------------------------- | ------------------------------ |
| edt_open_two_wire                            | Internal                       |
| edt_two_wire_read_type                       | Unused/Deprecated              |
| edt_two_wire_chg_bit                         | Internal                       |
| edt_two_wire_start                           | Internal                       |
| edt_two_wire_clock_hi                        | Internal                       |
| edt_two_wire_clock_low                       | Internal                       |
| edt_two_wire_wr_databit                      | Internal                       |
| edt_two_wire_stop                            | Internal                       |
| edt_two_wire_check_ack                       | Internal                       |
| edt_two_wire_read_8bits                      | Internal                       |
| edt_two_wire_write_8bits                     | Internal                       |
| struct Edt2WireRegArray                      | Internal                       |

**pdv_initcam.h**

| Function                                     | Reason                         |
| -------------------------------------------- | ------------------------------ |
| pdv_dep_set_default                          | Internal                       |
| printcfg                                     | Renamed to `pdv_printcfg`      |
| pdv_initcam_readcfg                          | Unused/Deprecated              |
| pdv_initcam_kbs_check_and_reset_camera       | Unused/Deprecated              |
| pdv_initcam_set_rci                          | Unused/Deprecated              |

**pdv_interlace.h**

| Function                                     | Reason                         |
| -------------------------------------------- | ------------------------------ |
| edt_set_post_process                         | Unused/Deprecated              |
| edt_set_process_mode                         | Unused/Deprecated              |
| edt_get_default_processor                    | Unused/Deprecated              |
| deIntlv_buffers                              | Unused/Deprecated              |

**pdv_irig.h**

| Function                                     | Reason                         |
| -------------------------------------------- | ------------------------------ |
| pdv_irig_set_slave                           | Unsupported feature in modern VL F1/F4 products |
| pdv_irig_is_slave                            | Unused/Deprecated              |
| pdv_irig_set_bcd                             | Renamed to pdv_irig_set_raw()  |

**edt_os_lnx.h** and/or **edt_os_nt.h**

| Function                                     | Reason                         |
| -------------------------------------------- | ------------------------------ |
| ASSERT                                       | Unused/Deprecated              |
| LaunchThread                                 | Unused/Deprecated              |
| WaitForThread                                | Unused/Deprecated              |
| InitializeCriticalSection  / init_critical   | Unused/Deprecated              |
| EnterCriticalSection / enter_critical        | Unused/Deprecated              |
| LeaveCriticalSection / leave_critical        | Unused/Deprecated              |
| DeleteCriticalSection / delete_critical      | Unused/Deprecated              |
| create_mutex_named                           | Unused/Deprecated              |
| create_mutex                                 | Unused/Deprecated              |
| delete_mutex                                 | Unused/Deprecated              |
| wait_mutex_timeout                           | Unused/Deprecated              |
| wait_mutex                                   | Unused/Deprecated              |
| release_mutex                                | Unused/Deprecated              |
| create_event                                 | Unused/Deprecated              |
| wait_on_event_timeout                        | Unused/Deprecated              |
| wait_on_event                                | Unused/Deprecated              |
| signal_event                                 | Unused/Deprecated              |
| clear_event                                  | Unused/Deprecated              |
| edt_get_dc                                   | Unused/Deprecated              |
| edt_release_dc                               | Unused/Deprecated              |

## Discontinued Hardware

Support for the following EDT hardware has been removed in the 6.0.0 release.

```
PC/104 ICB

PCI 11W
PCI 16D
PCI 53B
PCI CD-16
PCI CD-20
PCI CD-40
PCI CD-60
PCI CDa
PCI CDa-16
PCI GP-20
PCI GP-40
PCI GP-60
PCI GP-ECL
PCI GP-THARAS
PCI GS-16
PCI GS-4
PCI SS-16
PCI SS-4
PCIe4 AMC16
PCIe8 G2 V7
PCIe8 G3 KU

PCI CD C-Link
PCI DV
PCI DV AERO SERIAL
PCI DV C-Link
PCI DV CLS
PCI DV FCI AIAG
PCI DV FCI USPS
PCI DV FOI
PCI DV FOX
PCI DV-RGB
PCI DV44
PCI DVA
PCI DVA 16
PCI DVK
PCIe4 DV C-Link
PCIe4 DV FCI
PCIe4 DV FOX
PCIe4 DVA FOX
PCIe4 PCD FOX
PCIe4 VisionLink FOX4
PCIe8 DV C-Link
PCIe8 DV CLS
PCIe8 DV FCI
PCIe8 DV FOX
PCIe8 DVa CLS
PCIe8 DVA FOX

SNAP1
WSU1

16TE3 Mezzanine
DDSP Mezzanine
DRX Mezzanine
HRC Mezzanine
MSDV Mezzanine
NET10G Mezzanine
OC192 Mezzanine
OCM Mezzanine
OCM2P7G Mezzanine
RS422/LVDS Mezzanine
TLK1501 Mezzanine
```

## Deprecated Applications

The following applications have been removed in the 6.0.0 release.


### From Both PCD and PDV Packages

```
bigread
dumpit
edt_sysinfo
optstr
pciediag
sample
trace
watchstat
xtest
```

### From PCD packages

```
16te3_set_e3
16te3_set_t3
c3_demux
c3_diffchk
c3_diffprbs
c3_e1chk
c3_e1prbs
c3_e3chk
c3_e3prbs
c3_set_e1
c3_set_e3
c3_set_t1
c3test
cda_diffchk
cda_diffprbs
check_gap
check_gap_ss
ddsp_looptest
de1rd32
de1test16
de1test24
demux
diffchk
diffprbs
dualchannel
dvbtest
e1chk
e3chk
e3prbs
edt_ss_time
extbdid
fifotest48
fileprbs7
functintr
gp_getdata
gp_xtest
gptest
gs_temp
init_oc192_de1
kubitload
loopcombo
loophrc
loopssd16
lsbitfiles
msdv_snap
net10g_setup
oc192_clock
oc192_set
oc192_test
ocm_check
ocm_play
ocm_snap
ocmload
otu2snap
otuload
pcdin
pcdout
pcdrequest
pcdtest
pcdtest_bb
pcildku
pe4_rd16
pe4_wr16
pe4pcild
poketmux
rd16_dmy_dma
rd16_dmy_register
rd32ctr
rd4
rdpcd8
rdssdio
rdwr16
read_xfp_sfp
readssd
ReadXFPSFP
ReadXFPSFP
rfile
simple_config
simple_putframe
simple_resize
snap10g
srxlload
ssbasetest
sseload
sstestdiff
statintr
stm1e1prbs15
t1chk
t1prbs
test_in
testall_p12
testcombo
testdmainfo
testssmem
threep_clktest
threep_emac_read
threep_emac_test
threep_looptest
threep_p12_test
threep_readclks
threep_setup
threep_sfpp_dump
vco
wfile
wr16_dmy_dma
writessd
wrpcd8
x3gload
```

### From PDV Packages

```
checkcam
check_gap_cl
clink_counters
cl_logic
clsimvar
configure
countbits
ltconfig
new_strobe
pdbcls10b
pdvplayback
pdvrecord
rcxmake
setperiod
set_si5338
simple_bc
simple_etrig
simple_event
simplemem
simplest_take
speedtest
strobe
taketwo
usps_test
waitevent
```
