# README for "send_tiffs" Application

SPDX-License-Identifier: BSD-3-Clause

Copyright (C) 2011 Engineering Design Team, Inc.

Revised 2011-02-23

CHANGES
- 2005-06-07: Created.
- 2005-06-15: Added CODE OVERVIEW section.
- 2009-02-05: Updated COMMAND OPTIONS section
- 2009-10-15: Added RGB emulation.

## Introduction

send_tiffs is an example / demonstration application that shows how the EDT
library can be used to send images through the EDT Camera Link Simulator, the
VisionLink CLS. This example uses TIFF formatted images as input but programmers
can implement other image formats by linking the appropriate libraries and
modifying the code as needed.

IMPORTANT: When send_tiffs was originally written, the primary application was
a project that needed variable sized images, margins and margin colors, and
formatted image lists. As a result send_tiffs is more complicated than it needs
to be for most applications. The much simpler example simple_clsend.c was
created and we recommend starting with that instead, unless you need the
aforementioned specialized functionality.

The VisionLink CLS card can be configured so its output matches the output of
most cameras. For more information on that, see the VisionLink CLS user guide.

The program reads a list of images and sends each one through the simulator.
The images can be any size up to 4096 pixels wide by 15000 lines.

The VisionLink CLS can only be configured for 4 tap interleave, or no
interleave.

## Operation

Before running this program, the simulator card needs to be initialized and
set up. That can be done by using "clsiminit". That loads the clsim.bit bitfile
into the interface FPGA on the simulator card, and will set up the simulator
based on the given camera configuration file. For example,

    C:\EDT\pdv> clsiminit -f sim_4096x1280.cfg

...will setup the simulator according to the parameters specified in the
"sim_4096x1280.cfg" camera configuration file. See "clsiminit --help" for more
help with that program.

The simplest method of running send_tiffs is to run it without any arguments:

    C:\EDT\pdv> send_tiffs

send_tiffs looks in the file "imagelist" in the current directory by default and
reads in a list of TIFF images which will be sent through the simulator card.
The format of the list is given below in detail (see "Specifying Images"), but it
can simply be a list of filenames, one per line.

send_tiffs will then open the unit 0 card, which should be the simulator, and
then the program will loop through the list of images one at a time and send
each image.

If options such as unit number, image list file, number of buffers, etc. need to
be specified, see the "Command Options" section.

## Command Options

Running "send_tiffs --help" will display the command options:

The `-u`, `-N`, `-l` and `-t` options take a single numeric argument. For example,
`send_tiffs -N 10` will tell the program to use 10 DMA buffers.

All these options should be quite self-explanatory, except perhaps `-t`. This
option is used in case you have a large number of images in the image list but
want to send fewer than that. So if there are 2000 images in the image list you
can use `send_tiffs -t 10` to just send the first 10 images from that image list
file.

## Specifying Images

The send_tiffs program will read a file containing a list of images to send. The
name of the file is "imagelist" by default, but can be specified using the `-i`
option to the program as described above. The format of this file is now
described.

Each line of the file contains either a comment or information about an image
file. If the first character in the line is "#" the line is a comment and will
be ignored. Otherwise the first set of characters up to a space (" ") character
specifies the filename of the image file. The image file must be in TIFF format.
That filename is the only required piece of information, but the following can
optionally be specified:

- `FillA:Value` -- Sets the fill value for the left margin of the image as
  described in the VisionLink CLS user guide. Note that specifying "-1"
  (negative one) will tell the program to use the pixel value found in the first
  pixel of the first line in the image as the margin value.

- `FillB:Value` -- Sets the fill value for the right margin of the image as
  described in the VisionLink CLS user guide. Note that specifying "-1"
  (negative one) will tell the program to use the pixel value found in the last
  pixel of the first line in the image as the margin value.

- `hStart:Value` -- The value specifies where in the camera's image to place the
  image from the file. For example, a line with `image.tif hStart:600` will
  place the first pixel of the "image.tif" image at 600 pixels into the image
  seen from the camera. If hStart is not specified, the default behavior is to
  center the image file within the camera's image. That behavior can be
  specified manually by setting hStart to -1 ("image.tif hStart:-1"). Look for
  DEFAULT_HSTART in the source code to change this default.

- `vgap:Value` -- The value specifies how much vertical gap to have between the
  current image and the next image. If not specified anywhere, the value used is
  DEFAULT_VGAP in the source code.

Note that the value is always a numeric value specified in either decimal or
hexadecimal. To use hexadecimal, prefix the value with "0x". Note also that for
any image file listed, values not specified will be taken from the last line on
which they were specified or (if they were not specified) from the program
defaults as described for each parameter. Finally, the capitalization of the
parameters doesn't matter, but it is necessary that the value follows
immediately after with no space in between.

## Code Overview

The very first thing done by send_tiffs is parse command line arguments,
getting the list of images, and doing some initial setup such as creating the
EDT ring buffers and getting the simulated camera's size (as set by clsiminit).

Next, send_tiffs pre-loads all but the last ring buffer with the first images
from the image list.

The main loop of the program only has four things to do:

1. Start DMA to send the image data to the simulator.
2. Ensure the simulator gets setup for the *next* image that will be sent.
3. Get another image from the list and load it into the buffer that just
   finished being sent to the simulator.
4. Wait for the image we started sending at step 1.

The settings (width, height, etc.) for an image can be set on the simulator
any time before the simulator begins sending that image. That is, any time
before the simulator sets Frame Valid high.

Previously, step 2 was accomplished by watching a bit on the STATUS register of
the simulator which tells us if Frame Valid is high. Only when Frame Valid is
high would we set up for the next image. This was problematic because there is
no guarantee that we have not missed Frame Valid going high then low.

The new method is to use the EDT Event system, which makes the code much simpler
and ensures we never miss images.

With the EDT Event system, we use the following:

    edt_set_event_func(pdv_p,
                       EDT_PDV_EVENT_FVAL,
                       (EdtEventFunc)setup_clsim_event,
                       &callback_info,
                       1);


...to register a function (`setup_clsim_event()`) which will be called when the
driver receives an interrupt notifying it that Frame Valid went high. As soon as
frame valid goes high it is possible to setup the simulator for the next image,
and that is exactly what `setup_clsim_event()` does.

Although the Event system is better, it may not be clear how the timing works in
the program now. Here is a timing diagram showing when different things are
happening and for how long. (If the diagram doesn't look readable, try using an
editor with a monospaced font, like "edit" on windows or VI on Unix).

          _______________________    _______________________
    _____|                       |__|                       |_____  DMA
            _______________________    _______________________
    _______|*                      |__|*                      |___  Frame Valid
            __________________         __________________
    _______|                  |_______|                  |________  Image Loading

    * = Setup for next image happens at rising edge of Frame Valid


The DMA starts with the program's call to `edt_start_buffers(pdv_p, 1)`.
After the simulator has gotten 16 Kbytes of data it will start sending that out
to the frame grabber and at the same time it will send the FVAL interrupt to
the driver which will in turn call the `setup_clsim_event()` (see the asterisk
in the diagram). Immediately after the program calls edt_start_buffers it will
load the next image into the buffer most recently sent (so the buffer being
loaded is just behind the buffer being sent). Note that the image loading should
take less time than the DMA transfer for maximum speed.
