# Using VisionLink Frame Grabbers With Two Cameras

SPDX-License-Identifier: BSD-3-Clause

Copyright (C) 2011 Engineering Design Team, Inc.

The VisionLink boards can be used with two base-mode Camera Link cameras,
treating each camera as if it were on its own board. It does this by creating
two devices pdv0_0 and pdv0_1 (channels 0 and 1) which can be opened
independently. Each gets its own DMA channel, its own serial channel, and its
own set of registers on the board.

## Using the Supplied Software With Two Channels

To use the two channels, you need to specify the channel when opening the device.
Normally, the default behavior of the programs provided with the driver is to
open channel 0, so if there is a single camera the channel number is optional.

For example, to initialize a camera on channel 1, run:

    initcam -u 0 -c 1 -f <cfg file name>

To capture a single image, run:

    take -u 0 -c 1

## Using the PDV Library With Two Channels

The only thing that generally needs to change is to use `pdv_open_channel()`
instead of `pdv_open()`.

If you want to run both cameras simultaneously in continuous acquire, you need
to be careful about calling `pdv_flush_fifo()`, as it flushes both channels.
