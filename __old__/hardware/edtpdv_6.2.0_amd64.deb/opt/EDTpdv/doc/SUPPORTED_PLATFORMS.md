# Supported Platforms

SPDX-License-Identifier: BSD-3-Clause

Copyright (C) 2024 Engineering Design Team, Inc.

[TOC]

**NOTE:** All Linux distributions are x86-64 architectures, unless stated otherwise.

## 6.2.0

| Operating System | Version |
|---|---|
| AlmaLinux | 9.3 - 9.5 |
| CentOs Linux | 7.9 - 8.2 |
| CentOs Stream | 8.X - 9.6 |
| Debian | 11 - 12 |
| Fedora | 39, 40, 41 |
| NVIDIA Jetson Linux | 35.4.1 - 36.4.0 |
| RHEL | 8.X - 9.5 |
| RockyLinux | 9.3 - 9.5  |
| Ubuntu | 20.04 - 24.04 LTS |
| Windows | 10, build 1507 (64-bit) or newer |
| Windows | 10 (64-bit), build 1507 or newer |
| Windows | 11 (64-bit), build 22621 or newer |

## 6.1.0

| Operating System | Version |
|---|---|
| AlmaLinux | 9.3 |
| CentOs Linux | 7.9 - 8.2 |
| CentOs Stream | 8 - 9|
| Debian | 11 - 12 |
| Fedora | 37, 38, 39 |
| NVIDIA Jetson Linux | 35.4.1 - 36.4.0 |
| RHEL | 8.X - 9.3 |
| RockyLinux | 9.3  |
| Ubuntu | 20.04 - 22.04 LTS |
| Windows | 10, build 1507 (64-bit) or newer |
| Windows | 11, build 22621 (64-bit) or newer |

## 6.0.x

| Operating System | Version |
|---|---|
| CentOs Linux | 7.X - 8.2 |
| Debian | 10 - 12 |
| Fedora | 35, 36, 37, 38 |
| RHEL | 7.X - 8.5 |
| Ubuntu | 18.04 -  22.04 LTS |
| Windows | 10, build 1507 (64-bit) or newer |

## 5.6.2.0 - 5.6.3.0

| Operating System | Version |
|---|---|
| AlmaLinux | 8.5 | 
| CentOs Linux | 7.9 - 8.2 |
| CentOs Stream | 8 | 
| Debian | 10 - 11 |
| Fedora | 33, 34, 35|
| RHEL | 8.3 - 8.5 |
| Ubuntu | 18.04 (aarch64), 20.04 LTS |
| Windows | 7 SP1, 10 (32 and 64-bit) |

## Prior To 5.6.X.X

The operating systems listed here are not supported in the 6.X Driver/SDK.

Packages are available upon request (tech@edt.com) if need be, however technical support will be extrememly limited.

| EDT Package | Windows | 
| ---- | ---- |
| 5.5.x.x | 7 SP1, 10 (32 and 64-bit)
| 5.4.3.7 - 5.5.x.x | Windows 8, Server 2012* 32 and 64-bit
| 5.4.3.7 | 7, 32 and 64-bit
| 5.x  | Vista (x86 and x86-64), Server 2008*
| 5.x  | XP SP3 (32 and 64-bit), and Server 2003

