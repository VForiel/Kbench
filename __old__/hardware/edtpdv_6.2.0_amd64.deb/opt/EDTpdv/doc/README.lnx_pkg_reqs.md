# Linux Driver Dependencies

Engineering Design Team, Inc.

SPDX-License-Identifier: BSD-3-Clause
Copyright (C) 2011 Engineering Design Team, Inc.

Revised: Oct. 2023

## Introduction

EDT only tests on (and therefore supports) Ubuntu, Fedora, and CentOS
distributions. Kernel module support updates occur twice a year.

Beyond a basic OS installation, there are a few packages which are necessary
for the EDT software to run. This text gives a short description of which
extra packages (or package groups) may be needed on each major distribution.

In general, the EDT software needs standard C development tools (gcc/g++,
make, libc) plus the kernel development headers matching the currently loaded
kernel.

## Current Tested Distributions

There are numerous Linux distributions and versions; as of this writing the
following has been tested on the OS distrubtions listed here:
https://edt.com/faqs/what-operating-systems-are-supported/

Ubuntu & Debian installation requirements:

  - Linux kernel headers (`linux-headers-$(uname -r)`)

CentOS/RHEL/AlmaLinux & Fedora installation requirements:

  - Linux kernel headers(`[yum|dnf] install kernel-devel-$(uname -a)`)
  - Enable the EPEL repository (`[yum|dnf] install epel-release`), so the
    DKMS dependency may be installed.

## Supplemental Information for PDV (VisionLink products)

vlviewer is not compatible with PDV package v6.x.x. vlviewer for PDV v5.x is
available for download here: https://gitlab.com/engineering-design-team/vlviewer

## PCD Sub-Packages

The "drx16", "sse", "srxl" and "v4" sub-packages depend on the EDT PCD package.
Install the EDT PCD package first.

Note, however, that many of these sub-packages have **not** yet been updated
for use with PCD v6.x.x.
