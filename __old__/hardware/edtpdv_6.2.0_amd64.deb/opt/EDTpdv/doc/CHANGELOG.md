# Changelog

SPDX-License-Identifier: BSD-3-Clause

Copyright (C) 2022 Engineering Design Team, Inc.

[TOC]

## 6.2.0 - 2024-12-17

### Added

- [PCD] Initial support for PCIe WBx. [!233, !241]
- [PCD] `pciload` support for writing backup flash on RFx. [!201]

### Changed

- [Linux] Support Fedora 40 and kernel 6.10.x. [!216]
- [PCD] Updated `fourp` to configure A5/S5 properly for sustained 10 Gbit/s rates (write D0 register). [!222]
- [PDV] Updated libtiff from 3.8.2 (March 2006) to 4.7.0 (September 2024). [!220]
- [PDV] pdv_serial_wait() can now return -EBUSY if called from multiple threads. [!200]
- C standard updated from C89 with GNU extensions to C11, no extensions.
  Moving from outdated BSD/POSIX types to equivalent standard C99 types. [!202, !207, !209, !214, !215]
  - `u_char` -> `uint8_t`
  - `u_short` -> `uint16_t`
  - `u_int` -> `uint32_t` or `unsigned int`
  - `uchar_t` -> `unsigned char` or `uint8_t`
  - `ushort_t` -> `unsigned short` or `uint16_t`
  - `uint_t` -> `unsigned int` or `uint32_t`

### Deprecated

- [PCD] The `pcildcml` application. Use `pciload` to flash PCIe CML-ECL boards instead. [!233]

### Fixed

- `pciload` bitfile selection now checks bitfile prefix. E.g. `visionlinkf4` will match a `visionlinkf4-08.bit` file, `pe8s5_4p_a9` will match a `pe8s5_4p_a9-20.bit` file. [!244]
- [Linux] DEB/RPM packaging issue caused DKMS removal when upgrading or reinstalling the package. [!236]
- [Linux] Fixed memory mapping PCI BAR regions to user-space (edt_mapmem() for example) on AArch64. [!231]
  - On an NVIDIA Jetson SoM, memory mapping PCIe BARs with an invalid page offset caused an uncorrectable RAS error in L2 followed by a system crash.
- [PDV] gen_tiffs basename string overrun. Off-by-one error in pdv_mark_ras_depth() causing incorrect number to be generated in image. [!226]
- Missing bounds check in edt_set_buffer. [!221]
- [Linux] Add DMA unmap_single call for proper EDT page deallocation. [!219]
- [Linux] Replace obsoleted valloc() with posix_memalign().[!217]
- Unclear API documentation for edt_set_dmy_wait_for_buffers_callback(). [!218]
- Replace depreciated gethostbyname() with getaddrinfo(). [!213]
- [Linux] Driver module was not properly unloaded when installation updated. [!212]
- [PDV] Bug in `pdvterm` resulting in a failure to read an input file. [!197]
- [PDV] Several internal changes to pdv_serial_wait() to avoid bad performance in multithreaded code. [!200]
- API documentation URLs changed every release. Fixed by disabling Doxygen `SHORT_NAMES`. [!205]
- [Linux] Driver build for backported kernels in RHEL/AlmaLinux/Rocky Linux 6.4. [!210]

## 6.1.0 - 2024-02-29

### Added

- Windows and Linux installers create a `EDT_PCD_DIR` or `EDT_PDV_DIR` environment variable, which edt_home_dir() now looks for. [!168]
- Open calls (e.g. edt_open_device()) now check if the library and driver versions are compatible. [!181]
  - If the "major" (first) version numbers are different, the edt_open*() calls now return an error.
  - If lesser version numbers are different, a warning log message is emitted and the edt_open*() call succeeds.
- Example applications are provided pre-built in addition to their source files. [!192]

### Changed

- edt_get_parms_block() returns NULL, instead of `BAD_PARMS_BLOCK`, if bad flash parameters detected. [!174]

### Deprecated

- `BAD_PARMS_BLOCK` define. [!174]

### Removed

- edt_flash_read16(), edt_get_id_addrs(), edt_get_flash_file_header() were not implemented. [!174]
- [Windows] Move "Open in Powershell" shortcut from Start Menu to Desktop, to avoid Windows hiding one if both PCD and PDV are installed. [!190]
- [Windows] Excess Microsoft UCRT DLLs from package's "bin/" directory. [!190]
- bitfile_keys.h -- functions were not implimented. [!186]

### Fixed

- `pciload` fallback directory changed from `<InstallDir>/flash/` to `<InstallDir>/bitfiles/` to match the directory that firmware packages, such as `edt_fw_telecom`, install bitfiles. [!183]
- [PDV] VisionLink CLS firmware version string missing from pciload output. [!176]
- [PDV] pdv_serial_wait() returned msec delay instead of number of serial data bytes. [!177]
- `setdebug` memory corruption when attempting to read "todo list". [#139, !182]
- `setdebug` trace buffer indexing error. [#213, !182]
- [PCD] `fourp` continued to run after failing to open a dummy device. [!182]
- [PCD] Fix `fourp` / libocx accepting a non-existing port argument, causing transceiver reconfiguration errors. [!188]
- [PCD] `chkprbs15` data rate calculation in 'speedtest' option was wrong. [!187]
- Missing `extern "C"` from various C headers, namely pdv_initcam.h. [!186]
- [Linux] Kernel 3.10.0 support. Tested against 3.10.0-327.el7.x86_64. [!191]
- [Windows] Fixed slow access to ring buffer memory. [!193]

## 6.0.0 - 2023-12-19

### Added

- "libedt_version.h" header with more explicit version information.
- CMake config file, for use with CMake "find_package()".
- Add DKMS support, removing driver re-build functionality of edtinit.service. [!58]
- Add the following functions for access to data previously available via `EdtDev` structure. [!119]
  - edt_device_unit()
  - edt_device_channel()
  - edt_device_mezz_id()
  - edt_bitfile_get_descriptor()
  - edt_bitfile_get_mezz_descriptor()
  - edt_bitfile_option_string()
  - edt_bitfile_revision()
  - edt_dma_buffers_done_waiting()
  - edt_spi_set_base_address()
- Support for Linux kernel 6.5.x. [!144]
- Implement pdv_unload_postproc_module() [!153]

### Changed

- All Linux driver code built from source.
- libtiff statically linked into EDT's Linux libraries.
- Resolved Linux kernel driver compiler warnings. [!45]
- Removed flashing IOCTLs. FPGA bitfile flashing implementation is now constrained to the library. [!45]
- Cleanup clseredt.dll/libclseredt.so. Renamed header from "edt_camlink.h" to "libclseredt.h". [!55]
- License the Linux driver source as GNU GPL 2.0. Explicitly declare license of user-space libraries and applications as BSD 3-Clause.
- Linux driver uses modern PCI "probe" / "remove" callbacks for supported devices, instead of manual probing. [!69]
  - New v6.x driver may not detect devices when upgrading from v5.x to v6.x due to old v5.x driver failing to release resources.
    Simply restart the system and the v6.x driver should be able to probe EDT PCI devices properly.
- Linux driver adds/removes "/dev" interface files itself, instead of relying on external "edtinit" script. [!69]
- Applications and libraries in PCD and PDV packages only enumerate and interact with devices they support. [!70]
  - For example, `pciload` previously used to enumerate and show both PCD and PDV devices, but now pciload from the PCD package will only show PCD-type devices.
- Cleanup/refactoring example application sources. [!85, !90, !98, !99, !100, !101, !102, !103]
- `PdvDependent` is now an opaque pointer. Use `pdv_get_*()` or `pdv_set_*()` functions to access data previously directly accessible with this struct. [!115]
- `EdtDev` is now an opaque pointer. [!119]
- Linux driver exposes `reserve_pages` option as both a module parameter and a SysFS file (`/sys/bus/pci/drivers/edt_pci_<pcd|pdv>/reserve_pages`) [!144]
  - Sys config file (`/etc/sysconfig/edt/reserve_pages`) removed.

### Removed

- Support for Sun Solaris, VxWorks, and Apple operating systems.
- Support for Linux kernels older/earlier than v3.10.0.
- Support for Microsoft Windows older/earlier than Windows 10, build 1507.
- Support for building CLI application source code into other applications, using `NO_MAIN`.
- FPGA firmware (bitfiles) are no longer included, but will be available as separate packages.
- [PDV] Remove camera config files for deprecated "AIA" type frame grabbers.
  Common config files for CameraLink frame grabbers still exist in "./camera_config/" directory.
  Extra config files provided in "./camera_config/edt_camera_config_extra" archive.
- [PDV] Support for vlviewer v5.x GUI application.
- Support for discontinued products.
  A detailed list is provided in [changelog_addendum_v6.0.0](changelog_addendum_v6.0.0.md).
- Many IOCTLs unused by EDT code. [!54, !53]
- Linux driver `clear_cache` option. [!54]
- Linux "edtinit" service. [!69]
- Unused and/or deprecated C headers and library functions. [!77]
  A detailed list is provided in [changelog_addendum_v6.0.0](changelog_addendum_v6.0.0.md).

### Fixed

- When using a dummy device ("DMY_ID") the value of the nanoseconds field returned by edt_get_timestamp() was in microseconds. [!106]
- Memory leaks in send_tiffs example. [!151]
