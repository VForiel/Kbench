var modules =
[
    [ "IRIG-B Timecode Library", "group__libedt__timing.html", "group__libedt__timing" ],
    [ "EDT DMA Library", "group__dma.html", "group__dma" ],
    [ "EDT Digital Imaging Library", "group__dv.html", "group__dv" ],
    [ "EDT Message Handler Library", "group__msg.html", "group__msg" ],
    [ "EDT Camera Link Simulator Library", "group__cls.html", "group__cls" ],
    [ "Prominfo", "group__prominfo.html", "group__prominfo" ]
];