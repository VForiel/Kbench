var group__dma =
[
    [ "Open / Close", "group__docgroup__libedt__openclose.html", "group__docgroup__libedt__openclose" ],
    [ "DMA Initialization", "group__dma__init.html", "group__dma__init" ],
    [ "FIFO Flushing", "group__dma__fifo.html", "group__dma__fifo" ],
    [ "Input/Output", "group__dma__inout.html", "group__dma__inout" ],
    [ "Register Access", "group__docgroup__libedt__registers.html", "group__docgroup__libedt__registers" ],
    [ "Utility", "group__docgroup__libedt__utility.html", "group__docgroup__libedt__utility" ]
];