var structedt__msg__handler__s =
[
    [ "file", "structedt__msg__handler__s.html#a0ab8ee2bf85c30cddcbcbaa977f5f8e8", null ],
    [ "own_file", "structedt__msg__handler__s.html#a0bca6b998be8c4a0f286edbc3c83ef8c", null ]
];