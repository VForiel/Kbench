var structedt__dma__info =
[
    [ "used_dma", "structedt__dma__info.html#ae5c04f538f3b93ff37957d7a6ef357f1", null ],
    [ "alloc_dma", "structedt__dma__info.html#afc6f561a9374f8db0cd863251e025937", null ],
    [ "active_dma", "structedt__dma__info.html#a318f4ec142c1613c1016da24f6683b72", null ]
];