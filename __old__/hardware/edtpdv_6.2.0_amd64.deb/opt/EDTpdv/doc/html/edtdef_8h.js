var edtdef_8h =
[
    [ "EDT_INTERFACE", "edtdef_8h.html#a05cdfe22900180edc5208564e482cba1", null ]
];