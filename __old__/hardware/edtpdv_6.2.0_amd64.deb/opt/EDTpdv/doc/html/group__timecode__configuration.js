var group__timecode__configuration =
[
    [ "edt_set_timecode_seconds_offset", "group__timecode__configuration.html#gaafd9606b1786d94995cc0d9890b1f548", null ],
    [ "edt_spi_open", "group__timecode__configuration.html#ga937b71d433c71fe7bd261c94616d2b6e", null ],
    [ "edt_spi_close", "group__timecode__configuration.html#gabf78d7bce476b96ffd219eb3273975f9", null ],
    [ "edt_set_timecode_enable", "group__timecode__configuration.html#ga7d0ac652b1cd90e4e66df124bd3f0e86", null ],
    [ "edt_set_msp430_clock", "group__timecode__configuration.html#ga866474873e26529aeb358893feeecf83", null ],
    [ "edt_set_timecode_raw", "group__timecode__configuration.html#gac384d156023f71f1746e2f2c08941170", null ],
    [ "edt_enable_timecode_programmable_year", "group__timecode__configuration.html#ga4f7a8d9bff70ff63e3ec2db9bca765de", null ],
    [ "edt_disable_timecode_programmable_year", "group__timecode__configuration.html#gacfef87238a06c1a4c1c9fab2d06dba4a", null ]
];