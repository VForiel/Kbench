var group__libedt__timing =
[
    [ "Configuration Functions", "group__timecode__configuration.html", "group__timecode__configuration" ],
    [ "Display Functions", "group__timecode__display.html", "group__timecode__display" ],
    [ "Firmware Update Functions", "group__timecode__update.html", "group__timecode__update" ],
    [ "Utility Functions", "group__timecode__utility.html", "group__timecode__utility" ]
];