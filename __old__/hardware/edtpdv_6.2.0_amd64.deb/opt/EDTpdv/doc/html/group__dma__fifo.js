var group__dma__fifo =
[
    [ "edt_flush_fifo", "group__dma__fifo.html#gae4db0142f9fe7ecfca20423b6cb23f54", null ],
    [ "edt_set_firstflush", "group__dma__fifo.html#ga3fb5c0b4c299a0641efebedd59ce41c3", null ],
    [ "edt_enable_channels", "group__dma__fifo.html#ga405e69a25ef77feba250d78c63aa04fb", null ],
    [ "edt_enable_channel", "group__dma__fifo.html#ga1d7372fcff36c6dc082b6b8ffb346cde", null ],
    [ "edt_disable_channels", "group__dma__fifo.html#ga33c2098ea2c6d289a0b161d7b8d8f80d", null ],
    [ "edt_disable_channel", "group__dma__fifo.html#ga532932e11afafad0114562dd253980c7", null ]
];