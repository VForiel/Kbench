var group__docgroup__libedt__registers =
[
    [ "edt_reg_read", "group__docgroup__libedt__registers.html#ga23efce146acecfe4f5631fdf7a3fe7de", null ],
    [ "edt_reg_write", "group__docgroup__libedt__registers.html#gac036f005be4bfaba520d69cf67364f50", null ],
    [ "edt_reg_or", "group__docgroup__libedt__registers.html#ga6e38c58d3b41070a38e615ebde54e64c", null ],
    [ "edt_reg_and", "group__docgroup__libedt__registers.html#gad6891013e1bf95486edeff1d8bbc718b", null ],
    [ "edt_reg_clearset", "group__docgroup__libedt__registers.html#ga735cfe11171eb792db6162a10d9eee5a", null ],
    [ "edt_reg_setclear", "group__docgroup__libedt__registers.html#ga687282808b8a8d145815a3fd02c12ae3", null ],
    [ "edt_intfc_write8", "group__docgroup__libedt__registers.html#gae5ffbf71401058853ca4fb944f97f58a", null ],
    [ "edt_intfc_read8", "group__docgroup__libedt__registers.html#ga643c50bb099e458d0d82a2fafd272601", null ],
    [ "edt_intfc_write16", "group__docgroup__libedt__registers.html#gabe41c192a816fdf9d1c660158304e848", null ],
    [ "edt_intfc_read16", "group__docgroup__libedt__registers.html#gae2830fa1903aa9dbaec26993b64078d0", null ],
    [ "edt_intfc_write32", "group__docgroup__libedt__registers.html#ga61bd76874932f63fe4d61e8083fb6279", null ],
    [ "edt_intfc_read32", "group__docgroup__libedt__registers.html#ga930b41617715ebd57f21020c8baa6b53", null ],
    [ "edt_bar1_write", "group__docgroup__libedt__registers.html#ga543ff4f7d962269ae7ee5352b5e1d529", null ],
    [ "edt_bar1_read", "group__docgroup__libedt__registers.html#gabdd12cec92b66982810c3f1a154b358a", null ]
];