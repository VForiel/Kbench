var dir_0cdb7d74c24148fa01c3964468acd2dd =
[
    [ "chardev_intf.h", "chardev__intf_8h.html", "chardev__intf_8h" ],
    [ "edt_lnx_alloc.h", "edt__lnx__alloc_8h.html", null ],
    [ "edt_lnx_kernel.h", "edt__lnx__kernel_8h.html", "edt__lnx__kernel_8h" ],
    [ "edt_lnx_mm.h", "edt__lnx__mm_8h.html", null ],
    [ "edt_mem_tag.h", "edt__mem__tag_8h.html", null ],
    [ "edtdrvlnx.h", "edtdrvlnx_8h.html", "edtdrvlnx_8h" ],
    [ "kcompat.h", "kcompat_8h.html", null ]
];