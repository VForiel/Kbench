var structEdtBoardInfo =
[
    [ "type", "structEdtBoardInfo.html#aaadda4f3cf5ccd3a7d1b428c9787b0db", null ],
    [ "id", "structEdtBoardInfo.html#afef559fdd66fe9fd40dfc45de6f188ed", null ],
    [ "bd_id", "structEdtBoardInfo.html#ac5038c8c2d79c633741d7fea8775f437", null ],
    [ "promcode", "structEdtBoardInfo.html#ac630e9db54a47da5b9c442cd2ba16901", null ]
];