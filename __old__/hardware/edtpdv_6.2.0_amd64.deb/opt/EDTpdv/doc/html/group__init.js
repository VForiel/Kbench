var group__init =
[
    [ "pdv_initcam", "group__init.html#ga7fe21fbfc6cac205175adba7a70c3763", null ],
    [ "pdv_readcfg", "group__init.html#ga744d403b029a7aa5a3a51b5fc84655de", null ],
    [ "pdv_alloc_dependent", "group__init.html#gadb1a0d4c0bf142d9c59239b2c31b4196", null ]
];