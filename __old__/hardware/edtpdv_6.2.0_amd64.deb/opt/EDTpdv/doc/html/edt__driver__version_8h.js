var edt__driver__version_8h =
[
    [ "EDT_DRIVER_VERSION", "edt__driver__version_8h.html#a405ccf823fa9b3da011cad645af04e6b", null ],
    [ "EDT_DRIVER_VERSION_LEN", "edt__driver__version_8h.html#a94e087dbde41a45b95222460cb5c0fa0", null ],
    [ "EDT_DRIVER_BUILDID", "edt__driver__version_8h.html#ac5708aab4e3908ffb077151ba0f6f8b3", null ],
    [ "EDT_DRIVER_BUILDID_LEN", "edt__driver__version_8h.html#a96d4cde1e23a1a2d7687c4df533ab048", null ]
];