var group__debug =
[
    [ "pdv_set_debug", "group__debug.html#gad1d73554418fec531d5a8d89401ea1ed", null ],
    [ "pdv_get_debug", "group__debug.html#ga019e7372e20877e7ddbdef525173ffb4", null ]
];