var globals_func =
[
    [ "b", "globals_func.html", null ],
    [ "c", "globals_func_c.html", null ],
    [ "e", "globals_func_e.html", null ],
    [ "f", "globals_func_f.html", null ],
    [ "g", "globals_func_g.html", null ],
    [ "i", "globals_func_i.html", null ],
    [ "l", "globals_func_l.html", null ],
    [ "m", "globals_func_m.html", null ],
    [ "p", "globals_func_p.html", null ],
    [ "s", "globals_func_s.html", null ],
    [ "u", "globals_func_u.html", null ]
];