var Edt__Dev_8h =
[
    [ "edt_and", "Edt__Dev_8h.html#a63ad6216f076dce6909c17b137c25232", null ],
    [ "edt_wakeup_dma", "Edt__Dev_8h.html#a136bfb9e5c7364321ad866c3bc79d8ec", null ],
    [ "edt_allocate_sglist", "Edt__Dev_8h.html#ab7b8a0a295d2d5887caad2051e286793", null ],
    [ "edt_dma_chan_info", "Edt__Dev_8h.html#a6c4684fdfb242a7621b796c0eb84d0f0", null ],
    [ "edt_initialize_vars", "Edt__Dev_8h.html#a603ea5a16c5eb1f071fafec7347d1f92", null ],
    [ "edt_get_active_channels", "Edt__Dev_8h.html#af62d8604e1e539cf796e669b725ae343", null ],
    [ "edt_default_rbufs_from_type", "Edt__Dev_8h.html#ab54ec5c69f34a2e0aa5f12dca3c79a7b", null ]
];