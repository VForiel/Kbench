var edt__pci__devices_8h =
[
    [ "PCI_VENDOR_ID_EDT", "edt__pci__devices_8h.html#a1bb00d1f57d32b909759dd85bb6be43f", null ],
    [ "EDT_PCI_PID", "edt__pci__devices_8h.html#ad3a8b100177f168b7c2276d442a66d07", [
      [ "EDT_PCI_UNKNOWN_ID", "edt__pci__devices_8h.html#ad3a8b100177f168b7c2276d442a66d07a106098fb8480d68a24618264a7deb7fc", null ],
      [ "DMY_ID", "edt__pci__devices_8h.html#ad3a8b100177f168b7c2276d442a66d07ac7121a1a51acccb9875060c33de468e7", null ]
    ] ]
];