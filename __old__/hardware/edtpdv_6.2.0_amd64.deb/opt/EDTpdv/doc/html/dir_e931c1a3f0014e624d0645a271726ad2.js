var dir_e931c1a3f0014e624d0645a271726ad2 =
[
    [ "send_tiffs.c", "send__tiffs_8c.html", "send__tiffs_8c" ],
    [ "serial_cmd.c", "serial__cmd_8c.html", "serial__cmd_8c" ],
    [ "simple_clsend.c", "simple__clsend_8c.html", "simple__clsend_8c" ],
    [ "simple_irig2.c", "simple__irig2_8c.html", "simple__irig2_8c" ],
    [ "simple_sequence.c", "simple__sequence_8c.html", "simple__sequence_8c" ],
    [ "simple_take.c", "simple__take_8c.html", "simple__take_8c" ]
];