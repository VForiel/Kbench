var edt__shared__types_8h =
[
    [ "edt_timespec", "structedt__timespec.html", "structedt__timespec" ],
    [ "edt_dma_info", "structedt__dma__info.html", "structedt__dma__info" ],
    [ "EDT_USER_BUFS", "edt__shared__types_8h.html#ad72ed80c4556612ee9d97aa4bc42932e", null ],
    [ "EDT_COPY_KBUFS", "edt__shared__types_8h.html#a490b58edc8a3eb45af8798f92555740b", null ],
    [ "EDT_MMAP_KBUFS", "edt__shared__types_8h.html#a122982289560f990f6f70ef237ca35fe", null ],
    [ "edt_bitpath", "edt__shared__types_8h.html#a01a717b59e822dce32b3d34e733401d1", null ],
    [ "edt_timespec_t", "edt__shared__types_8h.html#ae9fe99859acd54774d36b01fab01693f", null ],
    [ "edt_dma_info_t", "edt__shared__types_8h.html#aab7285ee66f5f578a4158919d1e9a663", null ],
    [ "EdtDmaTimeoutAction", "edt__shared__types_8h.html#a5b21495126d29cd6a627c7ca48da716e", null ],
    [ "edt_dma_wait_status", "edt__shared__types_8h.html#aa2d48a3be6f71f46e26861e5be830812", [
      [ "EDT_WAIT_UNKNOWN", "edt__shared__types_8h.html#aa2d48a3be6f71f46e26861e5be830812a4994d00b1e0db55232c00600d6809c4a", null ]
    ] ],
    [ "edt_dma_timeout_action", "edt__shared__types_8h.html#a11742b43a055e5172eb206903cccd270", [
      [ "EDT_TIMEOUT_NULL", "edt__shared__types_8h.html#a11742b43a055e5172eb206903cccd270a2604ed14e1ba956ba68d5bf300c0c9b2", null ],
      [ "EDT_TIMEOUT_BIT_STROBE", "edt__shared__types_8h.html#a11742b43a055e5172eb206903cccd270abd7cd5fd67de02adeb2388d2357ee304", null ]
    ] ],
    [ "edt_kernel_event", "edt__shared__types_8h.html#a2db487b5ee8868f633716233f55ce3bc", [
      [ "EDT_PDV_EVENT_ACQUIRE", "edt__shared__types_8h.html#a2db487b5ee8868f633716233f55ce3bca0303648109bf15da09da578cbc0665ff", null ],
      [ "EDT_EVENT_PCD_STAT1", "edt__shared__types_8h.html#a2db487b5ee8868f633716233f55ce3bcadde293b7eb06878ecd05e607fea3056f", null ],
      [ "EDT_EVENT_PCD_STAT2", "edt__shared__types_8h.html#a2db487b5ee8868f633716233f55ce3bca412e4ef5c4bd1acd6f4d5c683cb8856b", null ],
      [ "EDT_EVENT_PCD_STAT3", "edt__shared__types_8h.html#a2db487b5ee8868f633716233f55ce3bcabe875009cead6dc88b1ec1b211c24e51", null ],
      [ "EDT_EVENT_PCD_STAT4", "edt__shared__types_8h.html#a2db487b5ee8868f633716233f55ce3bca8ce8a969cb86161928e5ec409213cc7d", null ],
      [ "EDT_PDV_EVENT_FVAL", "edt__shared__types_8h.html#a2db487b5ee8868f633716233f55ce3bca53892b8364b3147869b93c5d8bb7c413", null ]
    ] ]
];