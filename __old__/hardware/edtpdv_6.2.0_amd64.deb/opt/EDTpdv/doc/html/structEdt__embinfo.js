var structEdt__embinfo =
[
    [ "sn", "structEdt__embinfo.html#a0c9eba51a22170d359302a0e27e57bba", null ],
    [ "pn", "structEdt__embinfo.html#a478501cce638517c05b48a8de050ba34", null ],
    [ "opt", "structEdt__embinfo.html#abde7db37cef019ea3c6c40b84183b8f3", null ],
    [ "rev", "structEdt__embinfo.html#a70aefe7f09196bbcfa9959435e8fbd71", null ]
];