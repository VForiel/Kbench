var group__timecode__utility =
[
    [ "edt_spi_send_packet", "group__timecode__utility.html#ga17c5ec14921b0ac80bdd9c8a38eee34c", null ],
    [ "edt_spi_get_byte", "group__timecode__utility.html#ga4e48cb9d94db95848e924571042b8fbf", null ],
    [ "edt_spi_put_byte", "group__timecode__utility.html#ga7a00bcee51dc37eaabe1e1006656c84d", null ],
    [ "edt_spi_flush_fifo", "group__timecode__utility.html#gaddd5ec85c0a1e5427734b010bde99f1c", null ],
    [ "edt_spi_putstr", "group__timecode__utility.html#ga5f48fbbb4feae983172a80d73ce3fe26", null ]
];