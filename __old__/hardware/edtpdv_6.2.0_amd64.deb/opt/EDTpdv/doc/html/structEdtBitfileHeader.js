var structEdtBitfileHeader =
[
    [ "ncdname", "structEdtBitfileHeader.html#a6b7be32cdb7a6165be6f8abf3e3ea7e8", null ],
    [ "date", "structEdtBitfileHeader.html#aa868715058ab2c52eaf71bba74ca162e", null ],
    [ "time", "structEdtBitfileHeader.html#a8461b02e8d426c769ac820e02ca59edd", null ],
    [ "magic", "structEdtBitfileHeader.html#a60eff8903f83c957f2afa53fb0f9bfd1", null ]
];