var annotated_dup =
[
    [ "_bitfile_list", "struct__bitfile__list.html", null ],
    [ "_ts_raw_t", "struct__ts__raw__t.html", null ],
    [ "edt_cdev_unit", "structedt__cdev__unit.html", "structedt__cdev__unit" ],
    [ "edt_dma_info", "structedt__dma__info.html", "structedt__dma__info" ],
    [ "Edt_embinfo", "structEdt__embinfo.html", "structEdt__embinfo" ],
    [ "edt_event_handler", "structedt__event__handler.html", "structedt__event__handler" ],
    [ "edt_msg_handler_s", "structedt__msg__handler__s.html", "structedt__msg__handler__s" ],
    [ "edt_pll", "structedt__pll.html", "structedt__pll" ],
    [ "edt_timespec", "structedt__timespec.html", "structedt__timespec" ],
    [ "edt_two_wire", "structedt__two__wire.html", "structedt__two__wire" ],
    [ "EdtBitfile", "structEdtBitfile.html", null ],
    [ "EdtBitfileHeader", "structEdtBitfileHeader.html", "structEdtBitfileHeader" ],
    [ "EdtBoardFpgas", "structEdtBoardFpgas.html", null ],
    [ "EdtBoardInfo", "structEdtBoardInfo.html", "structEdtBoardInfo" ],
    [ "Edtinfo", "structEdtinfo.html", null ],
    [ "EdtRegisterDescriptor", "structEdtRegisterDescriptor.html", "structEdtRegisterDescriptor" ],
    [ "image_info_t", "structimage__info__t.html", "structimage__info__t" ],
    [ "irig2_record", "structirig2__record.html", "structirig2__record" ],
    [ "libedt_version", "structlibedt__version.html", "structlibedt__version" ],
    [ "ser_buf", "structser__buf.html", null ],
    [ "serial_init_node", "structserial__init__node.html", null ]
];