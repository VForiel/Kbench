var searchData=
[
  ['two_5fwire_5fopt_5fclk_5fstretch_0',['TWO_WIRE_OPT_CLK_STRETCH',['../lib__two__wire_8h.html#a88f36393a1d46ad42d975960e7a95ca8a6149e6d414f5e2f68ca95ae7fad17569',1,'lib_two_wire.h']]]
];
