var searchData=
[
  ['open_20_2f_20close_0',['Open / Close',['../group__docgroup__libedt__openclose.html',1,'']]]
];
