var searchData=
[
  ['m_0',['m',['../structedt__pll.html#a2ba96d84885422e9e8da6f555b04154a',1,'edt_pll']]],
  ['magic_1',['magic',['../structEdtBitfileHeader.html#a60eff8903f83c957f2afa53fb0f9bfd1',1,'EdtBitfileHeader::magic()'],['../structirig2__record.html#af97834684051732b5f568b1f6285fe75',1,'irig2_record::magic()']]],
  ['main_2',['main',['../send__tiffs_8c.html#ac0f2228420376f4db7e1274f2b41667c',1,'main(int argc, const char *argv[]):&#160;send_tiffs.c'],['../serial__cmd_8c.html#ac0f2228420376f4db7e1274f2b41667c',1,'main(int argc, const char *argv[]):&#160;serial_cmd.c'],['../simple__clsend_8c.html#ac0f2228420376f4db7e1274f2b41667c',1,'main(int argc, const char *argv[]):&#160;simple_clsend.c'],['../simple__irig2_8c.html#ac0f2228420376f4db7e1274f2b41667c',1,'main(int argc, const char *argv[]):&#160;simple_irig2.c'],['../simple__sequence_8c.html#ac0f2228420376f4db7e1274f2b41667c',1,'main(int argc, const char *argv[]):&#160;simple_sequence.c'],['../simple__take_8c.html#ac0f2228420376f4db7e1274f2b41667c',1,'main(int argc, const char *argv[]):&#160;simple_take.c']]],
  ['major_3',['major',['../structlibedt__version.html#a4e16d95f37dbfd1402e99ca2d2c693cc',1,'libedt_version::major()'],['../structedt__cdev__unit.html#acc2f8dc56ef3136be95d5f1e58b60575',1,'edt_cdev_unit::major()']]],
  ['minor_4',['minor',['../structlibedt__version.html#a419d74ae339847dd8e363cd2a43efefe',1,'libedt_version']]]
];
