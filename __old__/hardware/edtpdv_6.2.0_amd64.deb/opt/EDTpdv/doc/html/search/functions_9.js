var searchData=
[
  ['strip_5fnl_0',['strip_nl',['../simple__clsend_8c.html#a6467c978c89961600b40462c79f90759',1,'simple_clsend.c']]]
];
