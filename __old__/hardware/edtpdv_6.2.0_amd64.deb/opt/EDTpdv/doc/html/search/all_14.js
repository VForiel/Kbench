var searchData=
[
  ['v_0',['v',['../structedt__pll.html#a6d3576d31b25c100e8144b618715aea0',1,'edt_pll']]],
  ['v6_2e0_2e0_20changelog_20addendum_1',['v6.0.0 Changelog Addendum',['../md_changelog_addendum_v6_0_0.html',1,'']]],
  ['vcs_5fid_2',['vcs_id',['../structlibedt__version.html#a5f110ce81b7cb9ba793bd71ea456ffab',1,'libedt_version']]]
];
