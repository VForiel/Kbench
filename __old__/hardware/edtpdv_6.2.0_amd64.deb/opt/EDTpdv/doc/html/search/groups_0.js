var searchData=
[
  ['acquisition_0',['Acquisition',['../group__acquisition.html',1,'']]]
];
