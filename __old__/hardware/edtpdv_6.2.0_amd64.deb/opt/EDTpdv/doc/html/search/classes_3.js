var searchData=
[
  ['libedt_5fversion_0',['libedt_version',['../structlibedt__version.html',1,'']]]
];
