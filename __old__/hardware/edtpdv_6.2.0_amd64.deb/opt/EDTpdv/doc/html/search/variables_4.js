var searchData=
[
  ['edt_5fdriver_5fbuildid_0',['EDT_DRIVER_BUILDID',['../edt__driver__version_8h.html#ac5708aab4e3908ffb077151ba0f6f8b3',1,'edt_driver_version.c']]],
  ['edt_5fdriver_5fbuildid_5flen_1',['EDT_DRIVER_BUILDID_LEN',['../edt__driver__version_8h.html#a96d4cde1e23a1a2d7687c4df533ab048',1,'edt_driver_version.c']]],
  ['edt_5fdriver_5fversion_2',['EDT_DRIVER_VERSION',['../edt__driver__version_8h.html#a405ccf823fa9b3da011cad645af04e6b',1,'edt_driver_version.c']]],
  ['edt_5fdriver_5fversion_5flen_3',['EDT_DRIVER_VERSION_LEN',['../edt__driver__version_8h.html#a94e087dbde41a45b95222460cb5c0fa0',1,'edt_driver_version.c']]]
];
