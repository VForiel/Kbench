var searchData=
[
  ['bibliography_0',['Bibliography',['../citelist.html',1,'']]]
];
