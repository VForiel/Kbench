var searchData=
[
  ['libedt_5fversion_5fmajor_0',['LIBEDT_VERSION_MAJOR',['../libedt__version_8h.html#ad21e861856c344247edb9ffcbf94fc81',1,'libedt_version.h']]],
  ['libedt_5fversion_5fminor_1',['LIBEDT_VERSION_MINOR',['../libedt__version_8h.html#a96ca67add890e7d521dddd3fec778847',1,'libedt_version.h']]],
  ['libedt_5fversion_5fpatch_2',['LIBEDT_VERSION_PATCH',['../libedt__version_8h.html#aca89465df409345ad683e5eac8ed9f1e',1,'libedt_version.h']]]
];
