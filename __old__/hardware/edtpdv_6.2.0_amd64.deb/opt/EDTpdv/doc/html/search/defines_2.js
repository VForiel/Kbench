var searchData=
[
  ['cl_5ferr_5fbaud_5frate_5fnot_5fsupported_0',['CL_ERR_BAUD_RATE_NOT_SUPPORTED',['../libclseredt_8h.html#a4465609f45249458953bd9b8098e700d',1,'libclseredt.h']]],
  ['cl_5ferr_5fbuffer_5ftoo_5fsmall_1',['CL_ERR_BUFFER_TOO_SMALL',['../libclseredt_8h.html#af6b68f173aaa3bf52e5a74d5395db27f',1,'libclseredt.h']]],
  ['cl_5ferr_5fedt_5fnot_5finitialized_2',['CL_ERR_EDT_NOT_INITIALIZED',['../libclseredt_8h.html#a9b2aaccec0f16083e4275b86c557d147',1,'libclseredt.h']]],
  ['cl_5ferr_5ferror_5fnot_5ffound_3',['CL_ERR_ERROR_NOT_FOUND',['../libclseredt_8h.html#a2da06c7b5ed46a4b7a0a083084c05940',1,'libclseredt.h']]],
  ['cl_5ferr_5ffunction_5fnot_5ffound_4',['CL_ERR_FUNCTION_NOT_FOUND',['../libclseredt_8h.html#a7d9302753d38684a0e6040fa0a527548',1,'libclseredt.h']]],
  ['cl_5ferr_5finvalid_5findex_5',['CL_ERR_INVALID_INDEX',['../libclseredt_8h.html#af6db4f6bf8d7dbddf8f693111ab498a2',1,'libclseredt.h']]],
  ['cl_5ferr_5finvalid_5fptr_6',['CL_ERR_INVALID_PTR',['../libclseredt_8h.html#a63d03451531dbc1f6cb073d23aedd0ab',1,'libclseredt.h']]],
  ['cl_5ferr_5finvalid_5freference_7',['CL_ERR_INVALID_REFERENCE',['../libclseredt_8h.html#a6ff20cb996946d452b928bfd4a34b5ea',1,'libclseredt.h']]],
  ['cl_5ferr_5fmanu_5fdoes_5fnot_5fexist_8',['CL_ERR_MANU_DOES_NOT_EXIST',['../libclseredt_8h.html#ac85848288171ad559dd1eb2b0534b25b',1,'libclseredt.h']]],
  ['cl_5ferr_5fno_5ferr_9',['CL_ERR_NO_ERR',['../libclseredt_8h.html#ab065c1b3aebe87109a559813b7389b76',1,'libclseredt.h']]],
  ['cl_5ferr_5fout_5fof_5fmemory_10',['CL_ERR_OUT_OF_MEMORY',['../libclseredt_8h.html#abaa85c3808afcd06477efe37dcee8b1a',1,'libclseredt.h']]],
  ['cl_5ferr_5fport_5fin_5fuse_11',['CL_ERR_PORT_IN_USE',['../libclseredt_8h.html#a95cdb8199b6a3e6177b84b9d8941be63',1,'libclseredt.h']]],
  ['cl_5ferr_5fregistry_5fkey_5fnot_5ffound_12',['CL_ERR_REGISTRY_KEY_NOT_FOUND',['../libclseredt_8h.html#a399abc8dea9246d85e7af3571af084eb',1,'libclseredt.h']]],
  ['cl_5ferr_5ftimeout_13',['CL_ERR_TIMEOUT',['../libclseredt_8h.html#a8339c8f806196eb68f87e23d81e09a87',1,'libclseredt.h']]],
  ['cl_5ferr_5funable_5fto_5fload_5fdll_14',['CL_ERR_UNABLE_TO_LOAD_DLL',['../libclseredt_8h.html#a605cb4d01b6ac848d80e496563582ca2',1,'libclseredt.h']]]
];
