var searchData=
[
  ['m_0',['m',['../structedt__pll.html#a2ba96d84885422e9e8da6f555b04154a',1,'edt_pll']]],
  ['magic_1',['magic',['../structEdtBitfileHeader.html#a60eff8903f83c957f2afa53fb0f9bfd1',1,'EdtBitfileHeader::magic()'],['../structirig2__record.html#af97834684051732b5f568b1f6285fe75',1,'irig2_record::magic()']]],
  ['major_2',['major',['../structlibedt__version.html#a4e16d95f37dbfd1402e99ca2d2c693cc',1,'libedt_version::major()'],['../structedt__cdev__unit.html#acc2f8dc56ef3136be95d5f1e58b60575',1,'edt_cdev_unit::major()']]],
  ['minor_3',['minor',['../structlibedt__version.html#a419d74ae339847dd8e363cd2a43efefe',1,'libedt_version']]]
];
