var searchData=
[
  ['used_5fdma_0',['used_dma',['../structedt__dma__info.html#ae5c04f538f3b93ff37957d7a6ef357f1',1,'edt_dma_info']]]
];
