var searchData=
[
  ['hserref_0',['hSerRef',['../libclseredt_8h.html#a2e25397904678218b4f51d351466d7a4',1,'libclseredt.h']]]
];
