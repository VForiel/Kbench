var searchData=
[
  ['t_0',['t',['../structirig2__record.html#a0867adbca80e7435dad563a68ffff786',1,'irig2_record']]],
  ['thrdid_1',['thrdid',['../structedt__event__handler.html#ac7f705d1a61c66dc27444e5e1a465e4e',1,'edt_event_handler::thrdid()'],['../structedt__event__handler.html#aee6f6e53ef702ef240d0defc2abbd2e9',1,'edt_event_handler::thrdid()']]],
  ['tickspps_2',['tickspps',['../structirig2__record.html#a96373295841ab5a5ca0fbf0a80be1433',1,'irig2_record']]],
  ['time_3',['time',['../structEdtBitfileHeader.html#a8461b02e8d426c769ac820e02ca59edd',1,'EdtBitfileHeader']]],
  ['timestamp_4',['timestamp',['../structirig2__record.html#ade2b3eceeb170b75b51fc656c40bbac1',1,'irig2_record']]],
  ['tv_5fnsec_5',['tv_nsec',['../structedt__timespec.html#a5de85292536a8695ff976af401a2b14c',1,'edt_timespec']]],
  ['tv_5fsec_6',['tv_sec',['../structedt__timespec.html#a0a3e56efcdd676f7b241e89e649a5b5e',1,'edt_timespec']]],
  ['type_7',['type',['../structEdtBoardInfo.html#aaadda4f3cf5ccd3a7d1b428c9787b0db',1,'EdtBoardInfo::type()'],['../structirig2__record.html#a0a03edcff7cccd13e86570d523ee1e8c',1,'irig2_record::type()']]]
];
