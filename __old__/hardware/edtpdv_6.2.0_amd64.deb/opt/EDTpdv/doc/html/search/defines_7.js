var searchData=
[
  ['pci_5fvendor_5fid_5fedt_0',['PCI_VENDOR_ID_EDT',['../edt__pci__devices_8h.html#a1bb00d1f57d32b909759dd85bb6be43f',1,'edt_pci_devices.h']]],
  ['pdv_5firig_5fspi_5fbase_1',['PDV_IRIG_SPI_BASE',['../libedt__timing_8h.html#abf9e4fbc9fbeb7bbcd120c27b7d37077',1,'libedt_timing.h']]]
];
