var searchData=
[
  ['get_5fbmp_5finfo_0',['get_bmp_info',['../simple__clsend_8c.html#a6ce32f6cb451b6c44598fea7b33542b4',1,'simple_clsend.c']]],
  ['get_5fgif_5finfo_1',['get_gif_info',['../simple__clsend_8c.html#aa0efb2693cfe283bc7fab5411b0051af',1,'simple_clsend.c']]],
  ['get_5fimage_5finfo_2',['get_image_info',['../simple__clsend_8c.html#a3684f8e27ef4b59f499772935ecf2649',1,'simple_clsend.c']]],
  ['get_5fimage_5finfo_5ffile_3',['get_image_info_file',['../simple__clsend_8c.html#a75dd3c13533618d37faea23e55effa4e',1,'simple_clsend.c']]],
  ['get_5fimages_5finfo_5fdir_4',['get_images_info_dir',['../simple__clsend_8c.html#a1ab472380d8e2104680b9839ce38a412',1,'simple_clsend.c']]],
  ['get_5fjpg_5finfo_5',['get_jpg_info',['../simple__clsend_8c.html#a980869a354b0aaac54a751761cda2a13',1,'simple_clsend.c']]],
  ['get_5fras_5finfo_6',['get_ras_info',['../simple__clsend_8c.html#ad714e50193aef5a0aa80f438a1d863c9',1,'simple_clsend.c']]],
  ['get_5fraw_5finfo_7',['get_raw_info',['../simple__clsend_8c.html#a436cd8fd6e2e202948cf2509702fb402',1,'simple_clsend.c']]],
  ['get_5ftif_5finfo_8',['get_tif_info',['../simple__clsend_8c.html#a6c90a8aac450632712ff61ad142aa461',1,'simple_clsend.c']]]
];
