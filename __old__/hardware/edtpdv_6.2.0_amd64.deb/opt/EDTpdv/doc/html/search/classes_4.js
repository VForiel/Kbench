var searchData=
[
  ['ser_5fbuf_0',['ser_buf',['../structser__buf.html',1,'']]],
  ['serial_5finit_5fnode_1',['serial_init_node',['../structserial__init__node.html',1,'']]]
];
