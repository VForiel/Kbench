var searchData=
[
  ['is_5fvalid_5ftiff_0',['is_valid_tiff',['../simple__clsend_8c.html#ab797892bada4c0460d628daf925f3bec',1,'simple_clsend.c']]]
];
