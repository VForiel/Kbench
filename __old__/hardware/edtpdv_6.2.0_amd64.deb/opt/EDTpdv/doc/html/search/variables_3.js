var searchData=
[
  ['data_0',['data',['../structimage__info__t.html#a834340399d615afd06fe67c385e6c78d',1,'image_info_t::data()'],['../structedt__event__handler.html#a823669cad06ac9a16d6989e6a155c967',1,'edt_event_handler::data()']]],
  ['date_1',['date',['../structEdtBitfileHeader.html#aa868715058ab2c52eaf71bba74ca162e',1,'EdtBitfileHeader']]],
  ['depth_2',['depth',['../structimage__info__t.html#a7dc7a7a363613d47a521d52acb131c17',1,'image_info_t']]]
];
