var searchData=
[
  ['acquisition_0',['Acquisition',['../group__acquisition.html',1,'']]],
  ['active_1',['active',['../structedt__event__handler.html#a0302043e83e2a58a0cde3866cd2a2b57',1,'edt_event_handler']]],
  ['active_5fdma_2',['active_dma',['../structedt__dma__info.html#a318f4ec142c1613c1016da24f6683b72',1,'edt_dma_info']]],
  ['address_5flength_3',['address_length',['../structedt__two__wire.html#aa4b588a3a7182bf07055fc1c57700d4a',1,'edt_two_wire']]],
  ['alloc_5fdma_4',['alloc_dma',['../structedt__dma__info.html#afc6f561a9374f8db0cd863251e025937',1,'edt_dma_info']]]
];
