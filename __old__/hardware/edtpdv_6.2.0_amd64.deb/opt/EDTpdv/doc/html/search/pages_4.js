var searchData=
[
  ['supported_20platforms_0',['Supported Platforms',['../md_doc_SUPPORTED_PLATFORMS.html',1,'']]]
];
