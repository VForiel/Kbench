var searchData=
[
  ['v6_2e0_2e0_20changelog_20addendum_0',['v6.0.0 Changelog Addendum',['../md_changelog_addendum_v6_0_0.html',1,'']]]
];
