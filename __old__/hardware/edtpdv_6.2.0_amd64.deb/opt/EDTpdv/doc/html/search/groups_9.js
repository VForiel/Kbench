var searchData=
[
  ['settings_0',['Settings',['../group__settings.html',1,'']]],
  ['startup_20_2f_20shutdown_1',['Startup / Shutdown',['../group__updown.html',1,'']]]
];
