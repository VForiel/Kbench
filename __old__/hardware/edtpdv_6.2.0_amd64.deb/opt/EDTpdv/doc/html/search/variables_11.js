var searchData=
[
  ['v_0',['v',['../structedt__pll.html#a6d3576d31b25c100e8144b618715aea0',1,'edt_pll']]],
  ['vcs_5fid_1',['vcs_id',['../structlibedt__version.html#a5f110ce81b7cb9ba793bd71ea456ffab',1,'libedt_version']]]
];
