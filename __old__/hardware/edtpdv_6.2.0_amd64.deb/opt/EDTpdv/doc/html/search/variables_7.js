var searchData=
[
  ['id_0',['id',['../structEdtBoardInfo.html#afef559fdd66fe9fd40dfc45de6f188ed',1,'EdtBoardInfo']]],
  ['irig_5fok_1',['irig_ok',['../structirig2__record.html#a08f6c6f2397f13642611738563200672',1,'irig2_record']]]
];
