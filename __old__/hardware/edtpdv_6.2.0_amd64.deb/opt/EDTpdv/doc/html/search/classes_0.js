var searchData=
[
  ['_5fbitfile_5flist_0',['_bitfile_list',['../struct__bitfile__list.html',1,'']]],
  ['_5fts_5fraw_5ft_1',['_ts_raw_t',['../struct__ts__raw__t.html',1,'']]]
];
