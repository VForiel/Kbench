var searchData=
[
  ['bands_0',['bands',['../structimage__info__t.html#a2dacee303daa91c47731fb81ce49c984',1,'image_info_t']]],
  ['bd_5fid_1',['bd_id',['../structEdtBoardInfo.html#ac5038c8c2d79c633741d7fea8775f437',1,'EdtBoardInfo']]],
  ['bitstart_2',['bitstart',['../structEdtRegisterDescriptor.html#a9a9b18d348e7257198509ae44519c1f5',1,'EdtRegisterDescriptor']]],
  ['build_5ftime_5fstr_3',['build_time_str',['../structlibedt__version.html#a2e1fb7d501470b283c74025c01305ea1',1,'libedt_version']]],
  ['build_5ftimestamp_4',['build_timestamp',['../structlibedt__version.html#aa9fddf4e88a088f4dfdf3a8ed205deca',1,'libedt_version']]]
];
