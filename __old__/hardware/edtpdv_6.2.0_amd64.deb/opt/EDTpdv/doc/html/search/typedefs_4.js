var searchData=
[
  ['libedt_5fversion_5ft_0',['libedt_version_t',['../libedt__version_8h.html#af476eaa15cee02c2ffc9c8bfe18b67cc',1,'libedt_version.h']]]
];
