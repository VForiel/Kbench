var indexSectionsWithContent =
{
  0: "_abcdefghiklmnoprstuvwx",
  1: "_eils",
  2: "ceklps",
  3: "bcefgilmpsu",
  4: "abcdefhilmnoprstuvwx",
  5: "cehilpst",
  6: "es",
  7: "dept",
  8: "_bcehilpt",
  9: "acdefioprsu",
  10: "bcdesv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules",
  10: "Pages"
};

