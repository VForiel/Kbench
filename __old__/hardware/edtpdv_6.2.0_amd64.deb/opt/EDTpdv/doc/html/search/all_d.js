var searchData=
[
  ['n_0',['n',['../structedt__pll.html#a13c8c6992c4ef38e633c3334448a21a7',1,'edt_pll']]],
  ['name_1',['name',['../structEdtRegisterDescriptor.html#ac63e78102412cddf0c171c662a26d725',1,'EdtRegisterDescriptor::name()'],['../structedt__cdev__unit.html#a909341ce68d73dd4f7e54c577106113c',1,'edt_cdev_unit::name()']]],
  ['nbits_2',['nbits',['../structEdtRegisterDescriptor.html#a9eeb092adcdbc5cedd8dd170163f536a',1,'EdtRegisterDescriptor']]],
  ['ncdname_3',['ncdname',['../structEdtBitfileHeader.html#a6b7be32cdb7a6165be6f8abf3e3ea7e8',1,'EdtBitfileHeader']]],
  ['next_4',['next',['../structedt__event__handler.html#a00976fd73405510d0c3315f409c39649',1,'edt_event_handler']]],
  ['num_5fnodes_5',['num_nodes',['../structedt__cdev__unit.html#a5acde6d6bd407e537aecd81f445eabe6',1,'edt_cdev_unit']]]
];
