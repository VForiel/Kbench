var searchData=
[
  ['register_20access_0',['Register Access',['../group__docgroup__libedt__registers.html',1,'']]]
];
