var structEdtRegisterDescriptor =
[
    [ "reg", "structEdtRegisterDescriptor.html#a94acbcb6cefc6be9f84ac68ea2639153", null ],
    [ "bitstart", "structEdtRegisterDescriptor.html#a9a9b18d348e7257198509ae44519c1f5", null ],
    [ "nbits", "structEdtRegisterDescriptor.html#a9eeb092adcdbc5cedd8dd170163f536a", null ],
    [ "name", "structEdtRegisterDescriptor.html#ac63e78102412cddf0c171c662a26d725", null ]
];