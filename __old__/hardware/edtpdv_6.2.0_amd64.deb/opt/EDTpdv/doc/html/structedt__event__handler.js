var structedt__event__handler =
[
    [ "next", "structedt__event__handler.html#a00976fd73405510d0c3315f409c39649", null ],
    [ "callback", "structedt__event__handler.html#a2fed7f789e5c4993697573c845ad9ee0", null ],
    [ "owner", "structedt__event__handler.html#afe15439a2e399938efeabb277b13ec0b", null ],
    [ "data", "structedt__event__handler.html#a823669cad06ac9a16d6989e6a155c967", null ],
    [ "active", "structedt__event__handler.html#a0302043e83e2a58a0cde3866cd2a2b57", null ],
    [ "continuous", "structedt__event__handler.html#a0f06353ff678e959e0428782049756b1", null ],
    [ "wait_thread", "structedt__event__handler.html#a6c6108f47712668ab25d6a9915709ba3", null ],
    [ "wait_event", "structedt__event__handler.html#a07d13899237e042710181485c81842a1", null ],
    [ "closing_event", "structedt__event__handler.html#a21840b89331db0f77e094a97328665e2", null ],
    [ "thrdid", "structedt__event__handler.html#ac7f705d1a61c66dc27444e5e1a465e4e", null ],
    [ "thrdid", "structedt__event__handler.html#aee6f6e53ef702ef240d0defc2abbd2e9", null ]
];