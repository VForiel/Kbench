/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "EDT PDV SDK Documentation", "index.html", [
    [ "EDT Application Programming Interface", "index.html", [
      [ "Introduction", "index.html#intro_sec", null ],
      [ "Libraries", "index.html#libraries", null ],
      [ "License, Terms of Use", "index.html#terms", null ],
      [ "Copyright, Trademarks", "index.html#trade", null ]
    ] ],
    [ "EDT PDV Quick Start Guide", "md_doc_README_pdv.html", [
      [ "Location of files", "md_doc_README_pdv.html#autotoc_md5", null ],
      [ "Introduction", "md_doc_README_pdv.html#autotoc_md6", null ],
      [ "Quick Start Guide", "md_doc_README_pdv.html#autotoc_md7", [
        [ "Windows", "md_doc_README_pdv.html#autotoc_md8", null ],
        [ "Linux", "md_doc_README_pdv.html#autotoc_md9", [
          [ "Linux Kernel Module", "md_doc_README_pdv.html#autotoc_md10", null ]
        ] ]
      ] ],
      [ "Updating Firmware", "md_doc_README_pdv.html#autotoc_md11", [
        [ "Frame Grabber Products", "md_doc_README_pdv.html#autotoc_md12", null ],
        [ "Remote Products (RCX Module)", "md_doc_README_pdv.html#autotoc_md13", null ]
      ] ],
      [ "Partial List of Included Files", "md_doc_README_pdv.html#autotoc_md14", null ]
    ] ],
    [ "Changelog", "md_CHANGELOG.html", [
      [ "6.2.0 - 2024-12-17", "md_CHANGELOG.html#autotoc_md23", [
        [ "Added", "md_CHANGELOG.html#autotoc_md24", null ],
        [ "Changed", "md_CHANGELOG.html#autotoc_md25", null ],
        [ "Deprecated", "md_CHANGELOG.html#autotoc_md26", null ],
        [ "Fixed", "md_CHANGELOG.html#autotoc_md27", null ]
      ] ],
      [ "6.1.0 - 2024-02-29", "md_CHANGELOG.html#autotoc_md28", [
        [ "Added", "md_CHANGELOG.html#autotoc_md29", null ],
        [ "Changed", "md_CHANGELOG.html#autotoc_md30", null ],
        [ "Deprecated", "md_CHANGELOG.html#autotoc_md31", null ],
        [ "Removed", "md_CHANGELOG.html#autotoc_md32", null ],
        [ "Fixed", "md_CHANGELOG.html#autotoc_md33", null ]
      ] ],
      [ "6.0.0 - 2023-12-19", "md_CHANGELOG.html#autotoc_md34", [
        [ "Added", "md_CHANGELOG.html#autotoc_md35", null ],
        [ "Changed", "md_CHANGELOG.html#autotoc_md36", null ],
        [ "Removed", "md_CHANGELOG.html#autotoc_md37", null ],
        [ "Fixed", "md_CHANGELOG.html#autotoc_md38", null ]
      ] ]
    ] ],
    [ "Erase Non-Volatile Memory on EDT Boards", "md_doc_README_erase_flash.html", [
      [ "What", "md_doc_README_erase_flash.html#autotoc_md1", null ],
      [ "How", "md_doc_README_erase_flash.html#autotoc_md2", null ]
    ] ],
    [ "v6.0.0 Changelog Addendum", "md_changelog_addendum_v6_0_0.html", [
      [ "Removed internal or deprecated headers", "md_changelog_addendum_v6_0_0.html#autotoc_md39", null ],
      [ "Removed API functions", "md_changelog_addendum_v6_0_0.html#autotoc_md40", null ],
      [ "Discontinued Hardware", "md_changelog_addendum_v6_0_0.html#autotoc_md41", null ],
      [ "Deprecated Applications", "md_changelog_addendum_v6_0_0.html#autotoc_md42", [
        [ "From Both PCD and PDV Packages", "md_changelog_addendum_v6_0_0.html#autotoc_md43", null ],
        [ "From PCD packages", "md_changelog_addendum_v6_0_0.html#autotoc_md44", null ],
        [ "From PDV Packages", "md_changelog_addendum_v6_0_0.html#autotoc_md45", null ]
      ] ]
    ] ],
    [ "Supported Platforms", "md_doc_SUPPORTED_PLATFORMS.html", [
      [ "6.2.0", "md_doc_SUPPORTED_PLATFORMS.html#autotoc_md18", null ],
      [ "6.1.0", "md_doc_SUPPORTED_PLATFORMS.html#autotoc_md19", null ],
      [ "6.0.x", "md_doc_SUPPORTED_PLATFORMS.html#autotoc_md20", null ],
      [ "5.6.2.0 - 5.6.3.0", "md_doc_SUPPORTED_PLATFORMS.html#autotoc_md21", null ],
      [ "Prior To 5.6.X.X", "md_doc_SUPPORTED_PLATFORMS.html#autotoc_md22", null ]
    ] ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Bibliography", "citelist.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"Edt__Dev_8h.html",
"group__cls.html#gac7929e7ac021ec46351b9413433957b7",
"group__settings.html#gab64d7936179e8d4620deacec01971ffb",
"pdv__interlace_8h.html#a907e5479c46e9978a245dd442e4d5923"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';