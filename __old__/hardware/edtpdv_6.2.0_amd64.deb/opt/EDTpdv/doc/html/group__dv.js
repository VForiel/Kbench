var group__dv =
[
    [ "Startup / Shutdown", "group__updown.html", "group__updown" ],
    [ "Settings", "group__settings.html", "group__settings" ],
    [ "Initialization", "group__init.html", "group__init" ],
    [ "Acquisition", "group__acquisition.html", "group__acquisition" ],
    [ "Communications/Control", "group__serial.html", "group__serial" ],
    [ "Utility", "group__utility.html", "group__utility" ],
    [ "Debug", "group__debug.html", "group__debug" ]
];