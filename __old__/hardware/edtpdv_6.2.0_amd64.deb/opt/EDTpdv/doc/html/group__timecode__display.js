var group__timecode__display =
[
    [ "edt_spi_get_stat", "group__timecode__display.html#gaabe4fd4504070395e2966598b699564b", null ],
    [ "edt_spi_display_time", "group__timecode__display.html#ga52e381315e23ffcd44d4485a87643484", null ]
];