var structedt__cdev__unit =
[
    [ "list_entry", "structedt__cdev__unit.html#a79cf70d64ee64e2abb6fdf5d9deae13c", null ],
    [ "private_data", "structedt__cdev__unit.html#aa120a89d7ffe04c7a2cbf397acdb3219", null ],
    [ "cdev", "structedt__cdev__unit.html#a43d80582d49c7ce39aa480d18a13eb8a", null ],
    [ "name", "structedt__cdev__unit.html#a909341ce68d73dd4f7e54c577106113c", null ],
    [ "major", "structedt__cdev__unit.html#acc2f8dc56ef3136be95d5f1e58b60575", null ],
    [ "lowest_minor", "structedt__cdev__unit.html#ae69c5f22aff34bf6e74946b6c4feb49d", null ],
    [ "num_nodes", "structedt__cdev__unit.html#a5acde6d6bd407e537aecd81f445eabe6", null ]
];