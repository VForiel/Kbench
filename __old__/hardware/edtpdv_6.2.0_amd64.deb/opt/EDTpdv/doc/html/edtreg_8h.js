var edtreg_8h =
[
    [ "EDT_IND_REG_1", "edtreg_8h.html#a08aa33828d8bfeb863778d24c92be36a", null ],
    [ "EDT_IND_REG_2", "edtreg_8h.html#a966e0275d9b8cc37ac45564c507797aa", null ],
    [ "EDT_IND_REG_4", "edtreg_8h.html#ad291e5a2c6e08b6c329893fb7265c2f2", null ],
    [ "EDT_IND_REG_3", "edtreg_8h.html#ac9f955ad422d787fba169fcae3494a33", null ],
    [ "EDT_BAR1_REG4", "edtreg_8h.html#ab1e73f8126e0f5a8aa591cb840ff47de", null ]
];