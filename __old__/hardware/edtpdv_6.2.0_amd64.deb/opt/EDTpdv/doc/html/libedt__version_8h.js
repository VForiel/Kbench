var libedt__version_8h =
[
    [ "libedt_version", "structlibedt__version.html", "structlibedt__version" ],
    [ "LIBEDT_VERSION_MAJOR", "libedt__version_8h.html#ad21e861856c344247edb9ffcbf94fc81", null ],
    [ "LIBEDT_VERSION_MINOR", "libedt__version_8h.html#a96ca67add890e7d521dddd3fec778847", null ],
    [ "LIBEDT_VERSION_PATCH", "libedt__version_8h.html#aca89465df409345ad683e5eac8ed9f1e", null ],
    [ "libedt_version_t", "libedt__version_8h.html#af476eaa15cee02c2ffc9c8bfe18b67cc", null ],
    [ "libedt_get_version", "libedt__version_8h.html#ac3ee8c86005865196c6fb957610189cf", null ],
    [ "libedt_get_version_str", "libedt__version_8h.html#a68c008ae442771d8d234f667a909ee63", null ],
    [ "libedt_get_version_str_full", "libedt__version_8h.html#a8e8014d9826c66d80c36f9738071e3f0", null ],
    [ "libedt_compiled_by", "libedt__version_8h.html#a5c9937befc51f0e565c119af86ee9651", null ]
];