var group__docgroup__libedt__openclose =
[
    [ "edt_close", "group__docgroup__libedt__openclose.html#ga41bc53ab22246c17dd19f584bcfcf00f", null ],
    [ "edt_open", "group__docgroup__libedt__openclose.html#ga4661acf392d02512db421db784297930", null ],
    [ "edt_open_quiet", "group__docgroup__libedt__openclose.html#gae225968289be0942ba41c42ad7bd5515", null ],
    [ "edt_open_channel", "group__docgroup__libedt__openclose.html#ga5f660fa20e87660c80e9ffd704089b2c", null ],
    [ "edt_open_device", "group__docgroup__libedt__openclose.html#ga793dd7c092c85c592def5b86fa60558a", null ],
    [ "edt_set_port", "group__docgroup__libedt__openclose.html#gadc92036a4349aaaac99f1157a71aaa84", null ],
    [ "edt_get_port", "group__docgroup__libedt__openclose.html#ga2c7eed1aca50d4e9488216d0ccae8024", null ]
];