var edt__lnx__kernel_8h =
[
    [ "edt_kmalloc", "edt__lnx__kernel_8h.html#aa7fa1e40c3ef37fb701c107b2ea63bd8", null ],
    [ "edt_cache_free_list_count", "edt__lnx__kernel_8h.html#acdfcd5c2727b9e07e8f50711185f0d2c", null ],
    [ "edt_mem_map_setup", "edt__lnx__kernel_8h.html#a8e3a3d6a484d7047a018118c40fd2dcf", null ],
    [ "edt_mem_map_clear_sg", "edt__lnx__kernel_8h.html#aeadd52b185fcaea0d5e66e35bf4beca1", null ]
];