var group__dma__init =
[
    [ "edt_bitload", "group__dma__init.html#ga152f6a701c85e4c96bd2c08e120e301a", null ]
];