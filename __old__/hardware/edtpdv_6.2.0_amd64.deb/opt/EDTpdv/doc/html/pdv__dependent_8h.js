var pdv__dependent_8h =
[
    [ "pdv_alloc_dependent", "group__init.html#gadb1a0d4c0bf142d9c59239b2c31b4196", null ],
    [ "pdv_dependent_erase", "pdv__dependent_8h.html#a3222a2afb9d8696aaef4e54fb22534d8", null ],
    [ "pdv_get_dependent", "pdv__dependent_8h.html#aad891b6dc7dc23ba11c4cbecf0f8a8e0", null ],
    [ "pdv_set_dependent", "pdv__dependent_8h.html#aea3ed84346bfa8f237cdf17e86041a47", null ]
];