var group__timecode__update =
[
    [ "edt_get_timecode_version", "group__timecode__update.html#ga65d713c9532e4649c10d44f600c65f6c", null ],
    [ "edt_spi_invoke_flash_loader", "group__timecode__update.html#ga9aae3ee75e4fe04293e3946f2b7a1bd7", null ]
];