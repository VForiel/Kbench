var edt__portability_8h =
[
    [ "EDT_API_LIBSHARED", "edt__portability_8h.html#a5b7f7a7d16292afa47fa756af4773c79", null ],
    [ "EDT_DEALLOCATE_WITH", "edt__portability_8h.html#a5807bef066d3a425f0a4b2c7b0dbf5d0", null ],
    [ "EDT_STR_FORMAT_ATTR", "edt__portability_8h.html#a520cba56c632a2818b472243781bff91", null ],
    [ "EDT_CHECK_RETURN", "edt__portability_8h.html#a2e555762bcd4f4863302d64092ed3ea4", null ],
    [ "EDT_DEPRECATED_FUNC", "edt__portability_8h.html#ab320920ac75e14a07844216c5a042a03", null ],
    [ "EDT_DEPRECATED_TYPE", "edt__portability_8h.html#a6610384c3e451db2895a55da57e7e5b3", null ]
];