# Erase Non-Volatile Memory on EDT Boards

Engineering Design Team, Inc.
https://edt.com

SPDX-License-Identifier: BSD-3-Clause
Copyright (C) 2011 Engineering Design Team, Inc.

Revised: Oct. 2023

## What

EDT PCIe boards incorporate one or more flash memory devices which store the
board's FPGA firmware (bitfile) along with identifying information such as part
number, serial number, or MAC addresses. The flash can be read and written by
EDT's `pciload` utility, and potentially other utilities using EDT libraries.

If needed, this memory can be erased(*). Completely erasing flash memory renders
the board unusable and, depending on the board being erased, it may need to be
returned to the factory for reprogramming if it is to be used again. Therefore
the erase functionality should only be used when necessary.

## How

Different EDT boards have different flash configurations, but the process for
erasing them is essentially the same. In general, all boards have one or more
primary and backup regions, which may be different sectors on the same flash
chip, or on different physical parts. The specific region of flash being booted
from is selected via a jumper on the board, labeled variously as `NORM`| `PROT`
or `PRI` | `SEC`, or similar silkscreening. Running

    pciload -p

...will show you all of the installed boards, and the region numbers for each
one.

To erase all regions on a board, simply run:

    pciload -u <unit> -s <region> ERASE

...separately for all regions that the board has, typically 0, 0 & 1, or 0
through 4. Since some boards have primary and backup regions in separate
flash devices, you should do the above with the jumper in the `NORM`/`PRI`
position, and again in the `PROT`/`SEC` position.

If after completing this process a pciload with no arguments still shows
header information in some regions, it means that your board model is one
of those with electrically protected region -- that is, a region that is
effectively read-only, meaning that any erasing or reprogramming of that
particular region can only be done at the factory. Some EDT boards
have this feature and some do not, but either way, performing the above
procedure will clear all of the board's erasable memory.

If your board is one that does have an electrically protected backup region,
recovery after an ERASE can be accomplished in the field by:

  - powering it up with the jumper in the `PROT`/`SEC` position
  - verifying that it can be seen by the host system using `pciload` with no arguments
  - moving the jumper to the `NORM`/`PRI` position, and
  - running: `pciload -u <unit> <fpga_file>`

Where `<fpga_file>` is the FPGA bitfile for your board. This will write
the firmware to the `NORM`/`PRI` flash region and will be loaded into the FPGA
the next time the board is power-cycled.

For information on specific FPGA configuration files, see the users guide
for your board. For complete pciload usage, run `pciload --help`. For support,
visit https://edt.com/support.

---

[*] This README applies to pciload as included in EDT PCD and PDV version
5.5.6.6 and later packages.
